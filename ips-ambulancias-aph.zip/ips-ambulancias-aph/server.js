'use strict';
const fs = require('fs');
const path = require('path');
const os = require('os');

// Lector mínimo de .env (sin dependencias)
try {
  const archivo = path.join(__dirname, '.env');
  if (fs.existsSync(archivo)) {
    for (const linea of fs.readFileSync(archivo, 'utf8').split(/\r?\n/)) {
      const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(linea);
      if (m && !linea.trim().startsWith('#') && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
    }
  }
} catch { /* sin .env */ }

const express = require('express');
const helmet = require('helmet');
const { abrir, auditar, iniciarRespaldosAutomaticos } = require('./src/db');
const seg = require('./src/seguridad');
const { crearRouter } = require('./src/rutas');

const config = {
  puerto: parseInt(process.env.PORT, 10) || 3000,
  host: process.env.HOST || '0.0.0.0',
  dirDatos: path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data')),
  empresaNombre: process.env.EMPRESA_NOMBRE || 'IPS de Ambulancias',
  empresaNit: process.env.EMPRESA_NIT || '',
  trustProxy: process.env.TRUST_PROXY === '1',
  sesionHoras: Math.min(72, Math.max(1, parseInt(process.env.SESION_HORAS, 10) || 12)),
};

async function asegurarAdministrador(db) {
  if (db.prepare('SELECT COUNT(*) n FROM usuarios').get().n > 0) return;
  const definida = process.env.ADMIN_CLAVE_INICIAL;
  const clave = definida || seg.claveTemporal();
  const info = db.prepare("INSERT INTO usuarios (usuario, nombre, rol, clave_hash, debe_cambiar, creado_en) VALUES ('admin','Administrador','admin',?,1,?)")
    .run(await seg.hashClave(clave), new Date().toISOString());
  auditar(db, null, 'ADMIN_INICIAL_CREADO', 'usuario', info.lastInsertRowid, null, { id: null, usuario: 'sistema' });
  const linea = '='.repeat(64);
  console.log(`\n${linea}\n  PRIMER INICIO: se creó el usuario administrador`);
  console.log('  Usuario: admin');
  console.log(definida ? '  Clave:   la definida en ADMIN_CLAVE_INICIAL' : `  Clave:   ${clave}`);
  console.log('  El sistema le pedirá cambiar la clave al ingresar.');
  if (!definida) console.log('  Anótela ahora: no se vuelve a mostrar.');
  console.log(`${linea}\n`);
}

function crearApp(db) {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy ? 1 : false);

  app.use(helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'"],
        imgSrc: ["'self'", 'data:', 'blob:'],
        connectSrc: ["'self'"],
        fontSrc: ["'self'"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        manifestSrc: ["'self'"],
        workerSrc: ["'self'"],
      },
    },
    crossOriginEmbedderPolicy: false,
    referrerPolicy: { policy: 'no-referrer' },
  }));
  app.use((_req, res, next) => {
    res.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
    next();
  });

  app.use('/api', (_req, res, next) => { res.set('Cache-Control', 'no-store'); next(); }, crearRouter({ db, config }));

  app.use(express.static(path.join(__dirname, 'public'), {
    index: 'index.html',
    setHeaders(res, ruta) {
      if (/(sw\.js|index\.html)$/.test(ruta)) res.set('Cache-Control', 'no-cache');
      if (ruta.endsWith('.webmanifest')) res.type('application/manifest+json');
    },
  }));
  app.use((_req, res) => res.status(404).type('text/plain').send('No encontrado'));
  return app;
}

async function iniciar() {
  const db = abrir(config.dirDatos);
  await asegurarAdministrador(db);
  iniciarRespaldosAutomaticos(db, config.dirDatos);
  const app = crearApp(db);
  const servidor = app.listen(config.puerto, config.host, () => {
    console.log(`Servidor listo en http://localhost:${config.puerto}`);
    const redes = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal);
    for (const r of redes) console.log(`  En la red local: http://${r.address}:${config.puerto}  (para instalar en el celular se necesita HTTPS, vea el README)`);
    console.log(`Datos en: ${config.dirDatos}`);
  });
  const cerrar = () => { servidor.close(() => { try { db.close(); } catch { /* ya cerrada */ } process.exit(0); }); setTimeout(() => process.exit(0), 4000).unref(); };
  process.on('SIGINT', cerrar);
  process.on('SIGTERM', cerrar);
}

if (require.main === module) {
  iniciar().catch((e) => { console.error('No se pudo iniciar el servidor:', e); process.exit(1); });
}

module.exports = { crearApp, config };

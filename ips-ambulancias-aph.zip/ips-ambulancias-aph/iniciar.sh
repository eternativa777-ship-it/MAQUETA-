#!/usr/bin/env sh
# Inicia el sistema en Linux o macOS. Requiere Node.js 20 o superior.
cd "$(dirname "$0")" || exit 1
[ -d node_modules ] || npm install --omit=dev
echo "Abra en el navegador: http://localhost:3000"
exec node server.js

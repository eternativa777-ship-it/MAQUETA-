'use strict';
/* Prueba automática de extremo a extremo: levanta el servidor con una base de datos temporal
 * y verifica seguridad, roles, validaciones, reportes y respaldos.   Uso: npm test          */
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const PUERTO = 3400 + Math.floor(Math.random() * 400);
const BASE = `http://127.0.0.1:${PUERTO}`;
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'aph-'));
const salidaDir = process.env.SALIDA_PRUEBAS || '';
const firma = fs.readFileSync(path.join(__dirname, 'firma-ejemplo.txt'), 'utf8');

let ok = 0, fallos = 0;
const verificar = (cond, msg, extra) => {
  if (cond) { ok++; console.log('  ok   ' + msg); } else { fallos++; console.log('  FALLA ' + msg + (extra !== undefined ? '  -> ' + JSON.stringify(extra).slice(0, 300) : '')); }
};

class Cliente {
  constructor() { this.cookies = {}; this.csrf = ''; }
  async llamar(metodo, ruta, cuerpo, extraHeaders = {}) {
    const h = { ...extraHeaders };
    if (cuerpo !== undefined) h['Content-Type'] = 'application/json';
    if (this.csrf && metodo !== 'GET') h['X-CSRF-Token'] = this.csrf;
    const c = Object.entries(this.cookies).map(([k, v]) => `${k}=${v}`).join('; ');
    if (c) h.Cookie = c;
    const r = await fetch(BASE + ruta, { method: metodo, headers: h, body: cuerpo === undefined ? undefined : JSON.stringify(cuerpo) });
    for (const sc of r.headers.getSetCookie()) {
      const [par] = sc.split(';'); const i = par.indexOf('=');
      if (/Max-Age=0|Expires=Thu, 01 Jan 1970/i.test(sc)) delete this.cookies[par.slice(0, i)]; else this.cookies[par.slice(0, i)] = par.slice(i + 1);
    }
    const tipo = r.headers.get('content-type') || '';
    let json = null, buf = null;
    if (tipo.includes('json')) json = await r.json().catch(() => null);
    else buf = Buffer.from(await r.arrayBuffer());
    return { status: r.status, json, buf, tipo, headers: r.headers };
  }
  async entrar(usuario, clave) {
    const r = await this.llamar('POST', '/api/login', { usuario, clave });
    if (r.status === 200) this.csrf = r.json.csrf;
    return r;
  }
}

const datosBase = (extra = {}) => ({
  fecha: '2026-09-27', hLlamada: '14:05', hSalida: '14:08', hSitio: '14:21', tipoAmb: 'Medicalizada (TAM)',
  tipoTraslado: 'Primario (del sitio a la IPS)', placaAmb: 'abc123', movil: 'Móvil 03', solicitante: 'Línea 123',
  tipoEvento: 'Accidente de tránsito', lugar: 'Autopista Norte con calle 170', municipio: 'Bogotá', departamento: 'Cundinamarca', zona: 'Urbana',
  condVictima: 'Motociclista', placaVehiculo: 'xyz98a', aseguradora: 'Seguros Ejemplo', poliza: '123456', estadoSoat: 'Asegurado', autoridad: 'Tránsito',
  tipoDoc: 'CC', numDoc: '1012345678', nombres: 'María Fernanda', apellidos: 'Gómez Rojas', sexo: 'Femenino', fechaNac: '1990-03-15', edad: '36',
  telefono: '3001234567', direccion: 'Calle 45 # 12-30', eps: 'EPS Ejemplo', regimen: 'Contributivo', acompNombre: 'Luis Gómez', acompParentesco: 'Hermano',
  motivo: 'Paciente motociclista con trauma en miembro inferior derecho tras colisión con vehículo.\nConsciente, refiere dolor intenso.',
  ta: '120/80', fc: '96', fr: '18', temp: '36.5', spo2: '97', gluco: '110', glasgow: '15', conciencia: 'Alerta',
  hallazgos: 'Deformidad en tercio medio de tibia derecha, sin sangrado activo.', diagnostico: 'Fractura de pierna', cie10: 's82.2',
  procedimientos: ['Inmovilización', 'Oxígeno', 'Canalización venosa'], insumos: 'SSN 0.9% 500 ml IV; Tramadol 50 mg IV', evolucion: 'Estable durante el traslado.',
  ipsReceptora: 'Hospital Ejemplo de Engativá', hLlegadaIps: '14:52', hEntrega: '14:58', recibeNombre: 'Dr. Andrés Pardo', recibeRegistro: 'Médico de urgencias',
  estadoEntrega: 'Estable', desenlace: 'Trasladado', observaciones: 'Sin novedades.', conductor: 'Carlos Ruiz', tripulante: 'Ana Torres', medico: 'Dr. Pedro Salas', docFirmante: '52123456',
  ...extra,
});

(async () => {
  const proc = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env: { ...process.env, PORT: String(PUERTO), HOST: '127.0.0.1', DATA_DIR: dir, EMPRESA_NOMBRE: 'IPS Ejemplo Ambulancias SAS', EMPRESA_NIT: '900.123.456-7' } });
  let consola = '';
  proc.stdout.on('data', (d) => { consola += d; }); proc.stderr.on('data', (d) => { consola += d; });
  const parar = () => { try { proc.kill(); } catch { /* ya terminó */ } };
  process.on('exit', parar);

  for (let i = 0; i < 60 && !/Servidor listo/.test(consola); i++) await new Promise((r) => setTimeout(r, 200));
  if (!/Servidor listo/.test(consola)) { console.log('El servidor no inició:\n' + consola); parar(); process.exit(1); }
  const claveAdminInicial = /Clave:\s+(\S+)/.exec(consola)?.[1];
  verificar(!!claveAdminInicial && claveAdminInicial.length === 12, 'primer inicio crea el administrador con clave aleatoria');

  console.log('\nSesión y contraseñas');
  const anon = new Cliente();
  verificar((await anon.llamar('GET', '/api/yo')).status === 401, 'sin sesión no se puede consultar el perfil');
  verificar((await anon.llamar('GET', '/api/atenciones')).status === 401, 'sin sesión no se listan atenciones');
  verificar((await anon.entrar('admin', 'incorrecta123')).status === 401, 'clave incorrecta es rechazada');
  const admin = new Cliente();
  const lg = await admin.entrar('admin', claveAdminInicial);
  verificar(lg.status === 200 && lg.json.debeCambiar === true, 'admin entra y debe cambiar la clave inicial');
  const setCookie = lg.headers.getSetCookie().join(' | ');
  verificar(/HttpOnly/i.test(setCookie) && /SameSite=Strict/i.test(setCookie), 'la cookie de sesión es HttpOnly y SameSite=Strict');
  const bloqueado = await admin.llamar('GET', '/api/atenciones');
  verificar(bloqueado.status === 403 && bloqueado.json.codigo === 'CAMBIAR_CLAVE', 'no se puede usar el sistema sin cambiar la clave inicial');
  const sinCsrf = new Cliente(); sinCsrf.cookies = { ...admin.cookies };
  verificar((await sinCsrf.llamar('POST', '/api/clave', { actual: claveAdminInicial, nueva: 'NuevaClave2026x' })).status === 403, 'una petición sin token CSRF es rechazada');
  verificar((await admin.llamar('POST', '/api/clave', { actual: claveAdminInicial, nueva: 'corta1' })).status === 400, 'clave débil es rechazada');
  verificar((await admin.llamar('POST', '/api/clave', { actual: claveAdminInicial, nueva: 'sololetrasaquiii' })).status === 400, 'clave sin números es rechazada');
  const CLAVE_ADMIN = 'ClaveSegura2026x';
  verificar((await admin.llamar('POST', '/api/clave', { actual: claveAdminInicial, nueva: CLAVE_ADMIN })).status === 200, 'admin cambia su clave');
  const origenAjeno = await admin.llamar('POST', '/api/usuarios', { usuario: 'x', nombre: 'xxx', rol: 'operador' }, { Origin: 'https://sitio-malicioso.com' });
  verificar(origenAjeno.status === 403, 'una petición que dice venir de otro sitio web es rechazada');

  console.log('\nUsuarios y roles');
  const nuevoOp = await admin.llamar('POST', '/api/usuarios', { usuario: 'ana.torres', nombre: 'Ana Torres', rol: 'operador' });
  verificar(nuevoOp.status === 201 && nuevoOp.json.claveTemporal?.length === 12, 'admin crea un operador con clave temporal');
  verificar((await admin.llamar('POST', '/api/usuarios', { usuario: 'ana.torres', nombre: 'Otra Persona', rol: 'operador' })).status === 409, 'no permite usuarios repetidos');
  const nuevoCon = await admin.llamar('POST', '/api/usuarios', { usuario: 'facturacion', nombre: 'Oficina Facturación', rol: 'consulta' });
  const op = new Cliente();
  verificar((await op.entrar('ana.torres', nuevoOp.json.claveTemporal)).status === 200, 'el operador inicia sesión con la clave temporal');
  verificar((await op.llamar('POST', '/api/clave', { actual: nuevoOp.json.claveTemporal, nueva: 'OperadorClave2026' })).status === 200, 'el operador cambia su clave');
  const con = new Cliente();
  await con.entrar('facturacion', nuevoCon.json.claveTemporal);
  await con.llamar('POST', '/api/clave', { actual: nuevoCon.json.claveTemporal, nueva: 'ConsultaClave2026' });
  verificar((await op.llamar('GET', '/api/usuarios')).status === 403, 'el operador no puede ver la lista de usuarios');
  verificar((await op.llamar('GET', '/api/auditoria')).status === 403, 'el operador no puede ver la auditoría');
  verificar((await op.llamar('GET', '/api/respaldo/descargar')).status === 403, 'el operador no puede descargar la base de datos');
  verificar((await admin.llamar('PUT', '/api/usuarios/1', { rol: 'operador' })).status === 400, 'el admin no puede quitarse su propio rol');

  console.log('\nRegistro de atenciones');
  const uuid1 = 'aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa';
  const malo = await op.llamar('POST', '/api/atenciones', { uuid: uuid1, datos: datosBase({ numDoc: '', tipoAmb: 'Nave espacial', placaAmb: 'A' }), firmaTrip: firma });
  verificar(malo.status === 400 && malo.json.campos?.numDoc && malo.json.campos?.tipoAmb && malo.json.campos?.placaAmb, 'datos inválidos devuelven el error de cada campo', malo.json);
  verificar((await op.llamar('POST', '/api/atenciones', { uuid: uuid1, datos: datosBase() })).status === 400, 'sin firma del tripulante no se guarda');
  verificar((await op.llamar('POST', '/api/atenciones', { uuid: uuid1, datos: datosBase(), firmaTrip: '<script>alert(1)</script>' })).status === 400, 'una firma que no es imagen se rechaza');
  const creada = await op.llamar('POST', '/api/atenciones', { uuid: uuid1, datos: datosBase(), firmaTrip: firma, firmaPac: firma });
  verificar(creada.status === 201 && /^APH-2026-000001$/.test(creada.json.consecutivo), 'operador registra una atención con consecutivo automático', creada.json);
  const repetida = await op.llamar('POST', '/api/atenciones', { uuid: uuid1, datos: datosBase(), firmaTrip: firma });
  verificar(repetida.status === 200 && repetida.json.repetido && repetida.json.id === creada.json.id, 'reenviar el mismo registro no lo duplica (sincronización sin señal)');
  const inyeccion = datosBase({ uuid2: 1, nombres: "Robert'); DROP TABLE atenciones;--", motivo: '<img src=x onerror=alert(1)>', campoInventado: 'x' });
  const c2 = await op.llamar('POST', '/api/atenciones', { uuid: 'bbbbbbbb-2222-4222-8222-bbbbbbbbbbbb', datos: inyeccion, firmaTrip: firma });
  verificar(c2.status === 201, 'texto con comillas y HTML se guarda como texto');
  const det = await admin.llamar('GET', `/api/atenciones/${c2.json.id}`);
  verificar(det.json?.datos?.campoInventado === undefined, 'los campos que no existen en el esquema se descartan');
  verificar((await admin.llamar('GET', '/api/atenciones')).json.total === 2, 'la tabla de atenciones sigue intacta tras el intento de inyección SQL');
  verificar((await admin.llamar('GET', "/api/atenciones?q=' OR 1=1 --")).json.total === 0, 'una búsqueda con SQL malicioso no devuelve nada');
  verificar((await op.llamar('PUT', `/api/atenciones/${creada.json.id}`, { datos: datosBase(), motivo: 'quiero cambiarlo' })).status === 403, 'el operador no puede modificar atenciones');
  verificar((await con.llamar('POST', '/api/atenciones', { uuid: 'cccccccc-3333-4333-8333-cccccccccccc', datos: datosBase(), firmaTrip: firma })).status === 403, 'el rol consulta no puede crear atenciones');
  const otroOp = await admin.llamar('POST', '/api/usuarios', { usuario: 'juan.perez', nombre: 'Juan Pérez', rol: 'operador' });
  const op2 = new Cliente(); await op2.entrar('juan.perez', otroOp.json.claveTemporal);
  await op2.llamar('POST', '/api/clave', { actual: otroOp.json.claveTemporal, nueva: 'JuanClave2026ok' });
  verificar((await op2.llamar('GET', `/api/atenciones/${creada.json.id}`)).status === 404, 'un operador no ve las atenciones de otro operador');
  verificar((await con.llamar('GET', '/api/atenciones')).json.total === 2, 'el rol consulta ve todas las atenciones');

  console.log('\nCambios del administrador');
  const idA = creada.json.id;
  verificar((await admin.llamar('PUT', `/api/atenciones/${idA}`, { datos: datosBase({ numDoc: '999' }) })).status === 400, 'editar sin motivo es rechazado');
  verificar((await admin.llamar('PUT', `/api/atenciones/${idA}`, { datos: datosBase(), motivo: 'sin cambios reales' })).status === 400, 'editar sin cambiar nada es rechazado');
  const edit = await admin.llamar('PUT', `/api/atenciones/${idA}`, { datos: datosBase({ numDoc: '1012345679', diagnostico: 'Fractura de tibia y peroné' }), motivo: 'Corrección del documento según cédula' });
  verificar(edit.status === 200 && edit.json.version === 2, 'el admin edita con motivo y sube la versión', edit.json);
  const hist = await admin.llamar('GET', `/api/atenciones/${idA}/historial`);
  verificar(hist.json?.length === 1 && hist.json[0].cambios['Número de documento']?.[0] === '1012345678', 'el historial conserva el valor anterior y el motivo', hist.json);
  const anul = await admin.llamar('POST', `/api/atenciones/${c2.json.id}/anular`, { motivo: 'Registro de prueba duplicado' });
  verificar(anul.status === 200, 'el admin anula (no borra) una atención');
  verificar((await admin.llamar('GET', '/api/atenciones?estado=anulado')).json.total === 1, 'el filtro por estado muestra las anuladas');
  verificar((await admin.llamar('DELETE', `/api/atenciones/${idA}`)).status === 404, 'no existe forma de borrar una atención por la API');

  console.log('\nReportes');
  const guardar = (nombre, buf) => { if (salidaDir) { fs.mkdirSync(salidaDir, { recursive: true }); fs.writeFileSync(path.join(salidaDir, nombre), buf); } };
  const pdf1 = await op.llamar('GET', `/api/atenciones/${idA}/pdf`);
  verificar(pdf1.status === 200 && pdf1.buf.subarray(0, 5).toString() === '%PDF-', 'soporte individual en PDF', pdf1.status); guardar('soporte.pdf', pdf1.buf);
  const doc1 = await op.llamar('GET', `/api/atenciones/${idA}/docx`);
  verificar(doc1.status === 200 && doc1.buf.subarray(0, 2).toString() === 'PK', 'soporte individual en Word', doc1.status); guardar('soporte.docx', doc1.buf);
  const anuladoPdf = await admin.llamar('GET', `/api/atenciones/${c2.json.id}/pdf`); guardar('soporte-anulado.pdf', anuladoPdf.buf);
  verificar(anuladoPdf.status === 200, 'soporte de una atención anulada (con marca ANULADO)');
  verificar((await op.llamar('GET', '/api/reportes/atenciones.xlsx')).status === 403, 'el operador no puede sacar reportes generales');
  for (const f of ['xlsx', 'pdf', 'docx']) {
    const r = await con.llamar('GET', `/api/reportes/atenciones.${f}?desde=2026-09-01&hasta=2026-09-30`);
    const magia = f === 'pdf' ? r.buf?.subarray(0, 5).toString() === '%PDF-' : r.buf?.subarray(0, 2).toString() === 'PK';
    verificar(r.status === 200 && magia, `reporte general en ${f.toUpperCase()} (rol consulta)`, r.status); if (r.buf) guardar(`reporte.${f}`, r.buf);
  }
  const vacio = await admin.llamar('GET', '/api/reportes/atenciones.pdf?desde=2020-01-01&hasta=2020-01-02');
  verificar(vacio.status === 200, 'reporte sin resultados se genera igual');
  const audX = await admin.llamar('GET', '/api/reportes/auditoria.xlsx'); guardar('auditoria.xlsx', audX.buf);
  verificar(audX.status === 200, 'auditoría exportable a Excel');
  const resp = await admin.llamar('GET', '/api/respaldo/descargar');
  verificar(resp.status === 200 && resp.buf.subarray(0, 15).toString() === 'SQLite format 3', 'el admin descarga una copia de la base de datos');
  const dash = await op.llamar('GET', '/api/resumen');
  verificar(dash.status === 200 && dash.json.total === 1, 'el resumen del operador cuenta solo sus atenciones', dash.json);

  console.log('\nBloqueo de cuenta y auditoría');
  const victima = new Cliente();
  for (let i = 0; i < 5; i++) await victima.entrar('juan.perez', 'mala-clave-' + i);
  verificar((await victima.entrar('juan.perez', 'JuanClave2026ok')).status === 401, 'tras 5 intentos fallidos la cuenta se bloquea aunque luego se use la clave correcta');
  const lista = await admin.llamar('GET', '/api/usuarios');
  verificar(lista.json.find((u) => u.usuario === 'juan.perez')?.bloqueado === true, 'el admin ve la cuenta bloqueada');
  verificar((await admin.llamar('PUT', `/api/usuarios/${otroOp.json.id}`, { desbloquear: true })).status === 200, 'el admin desbloquea la cuenta');
  verificar((await victima.entrar('juan.perez', 'JuanClave2026ok')).status === 200, 'la persona vuelve a entrar');
  const reinicio = await admin.llamar('POST', `/api/usuarios/${otroOp.json.id}/reiniciar-clave`);
  verificar(reinicio.status === 200 && reinicio.json.claveTemporal?.length === 12, 'el admin reinicia la clave de un usuario');
  verificar((await victima.llamar('GET', '/api/atenciones')).status === 401, 'al reiniciar la clave se cierran las sesiones abiertas de esa persona');
  await admin.llamar('PUT', `/api/usuarios/${otroOp.json.id}`, { activo: false });
  verificar((await new Cliente().entrar('juan.perez', reinicio.json.claveTemporal)).status === 401, 'un usuario desactivado no puede entrar');
  const aud = await admin.llamar('GET', '/api/auditoria');
  const acciones = new Set(aud.json.items.map((x) => x.accion));
  for (const a of ['LOGIN', 'LOGIN_FALLIDO', 'CUENTA_BLOQUEADA', 'ATENCION_CREADA', 'ATENCION_EDITADA', 'ATENCION_ANULADA', 'USUARIO_CREADO', 'CLAVE_REINICIADA', 'DESCARGA_SOPORTE', 'DESCARGA_REPORTE', 'DESCARGA_RESPALDO']) {
    verificar(acciones.has(a), `la auditoría registró ${a}`);
  }
  verificar((await admin.llamar('POST', '/api/logout', {})).status === 200 && (await admin.llamar('GET', '/api/yo')).status === 401, 'cerrar sesión invalida la sesión');

  console.log('\nPágina y cabeceras');
  const home = await fetch(BASE + '/');
  const csp = home.headers.get('content-security-policy') || '';
  verificar(home.status === 200, 'la página principal se sirve');
  verificar(/script-src 'self'/.test(csp) && /frame-ancestors 'none'/.test(csp), 'la política de contenido (CSP) bloquea scripts ajenos y marcos');
  verificar(!!home.headers.get('x-content-type-options') && !home.headers.get('x-powered-by'), 'cabeceras de seguridad activas y sin x-powered-by');
  verificar((await fetch(BASE + '/manifest.webmanifest')).status === 200 && (await fetch(BASE + '/sw.js')).status === 200, 'manifiesto y service worker disponibles para instalar la app');
  verificar((await fetch(BASE + '/../server.js')).status !== 200 && (await fetch(BASE + '/data/ips.db')).status === 404, 'la base de datos y el código no se pueden descargar desde la web');

  parar();
  console.log(`\n${ok} pruebas correctas, ${fallos} con falla`);
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* temporal */ }
  process.exit(fallos ? 1 : 0);
})().catch((e) => { console.error('Error en la prueba:', e); process.exit(1); });

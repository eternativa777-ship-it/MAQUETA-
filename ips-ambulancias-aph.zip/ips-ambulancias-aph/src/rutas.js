'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const express = require('express');
const rateLimit = require('express-rate-limit');

const esquema = require('./esquema');
const seg = require('./seguridad');
const { auditar, crearRespaldo, listarRespaldos } = require('./db');
const rep = require('./reportes');

const MAX_LISTA_DOCUMENTO = 5000;
const MAX_LISTA_EXCEL = 50000;
const POR_PAGINA = 25;

function crearRouter({ db, config }) {
  const r = express.Router();
  const emp = { nombre: config.empresaNombre, nit: config.empresaNit };
  const ahora = () => new Date().toISOString();
  const aviso = (res, codigo, error, extra = {}) => res.status(codigo).json({ error, ...extra });
  const escLike = (s) => s.replace(/[\\%_]/g, (m) => '\\' + m);

  /* ---------- Guardas generales ---------- */
  r.use(express.json({ limit: '1mb' }));
  r.use(seg.verificarOrigen);
  r.use(seg.cargarSesion(db));
  r.use(rateLimit({ windowMs: 5 * 60 * 1000, limit: 1500, standardHeaders: true, legacyHeaders: false, message: { error: 'Demasiadas solicitudes, espere un momento' } }));

  const limiteLogin = rateLimit({
    windowMs: 15 * 60 * 1000, limit: 30, skipSuccessfulRequests: true, standardHeaders: true, legacyHeaders: false,
    message: { error: 'Demasiados intentos desde este equipo. Espere 15 minutos.' },
  });

  const datosUsuario = (u, csrf) => ({ usuario: { id: u.id, usuario: u.usuario, nombre: u.nombre, rol: u.rol }, debeCambiar: !!u.debe_cambiar, csrf });

  /* ---------- Sesión ---------- */
  r.get('/salud', (_req, res) => res.json({ ok: true }));
  // Solo el nombre de la empresa, para mostrarlo en la pantalla de ingreso

  r.post('/login', limiteLogin, async (req, res) => {
    const usuario = typeof req.body?.usuario === 'string' ? req.body.usuario.trim().slice(0, 40) : '';
    const clave = typeof req.body?.clave === 'string' ? req.body.clave.slice(0, 200) : '';
    const generico = () => aviso(res, 401, 'Usuario o clave incorrectos. Si olvidó su clave, pida al administrador que la reinicie.');
    if (!usuario || !clave) return generico();

    const u = db.prepare('SELECT * FROM usuarios WHERE usuario = ?').get(usuario);
    if (!u || !u.activo || u.bloqueado_hasta > Date.now()) {
      await seg.gastarTiempo(clave);
      auditar(db, req, 'LOGIN_FALLIDO', 'usuario', u ? u.id : null, { usuario, motivo: !u ? 'no existe' : !u.activo ? 'inactivo' : 'bloqueado' }, { id: null, usuario });
      return generico();
    }
    if (!(await seg.verificarClave(clave, u.clave_hash))) {
      const intentos = u.intentos + 1;
      if (intentos >= 5) {
        db.prepare('UPDATE usuarios SET intentos = 0, bloqueado_hasta = ? WHERE id = ?').run(Date.now() + 15 * 60 * 1000, u.id);
        auditar(db, req, 'CUENTA_BLOQUEADA', 'usuario', u.id, '5 intentos fallidos, bloqueo de 15 minutos', { id: u.id, usuario: u.usuario });
      } else {
        db.prepare('UPDATE usuarios SET intentos = ? WHERE id = ?').run(intentos, u.id);
      }
      auditar(db, req, 'LOGIN_FALLIDO', 'usuario', u.id, { usuario, motivo: 'clave incorrecta' }, { id: u.id, usuario: u.usuario });
      return generico();
    }

    db.prepare('UPDATE usuarios SET intentos = 0, bloqueado_hasta = 0, ultimo_acceso = ? WHERE id = ?').run(ahora(), u.id);
    const s = seg.crearSesion(db, u.id, req, config.sesionHoras);
    seg.ponerCookie(req, res, s.token, s.maxAge);
    auditar(db, req, 'LOGIN', 'usuario', u.id, null, { id: u.id, usuario: u.usuario });
    res.json(datosUsuario(u, s.csrf));
  });

  r.post('/logout', (req, res) => {
    if (req.sesion) {
      seg.exigirCsrf(req, res, () => {
        db.prepare('DELETE FROM sesiones WHERE token_hash = ?').run(req.sesion.hash);
        auditar(db, req, 'LOGOUT', 'usuario', req.usuario.id);
        seg.quitarCookie(req, res);
        res.json({ ok: true });
      });
    } else {
      seg.quitarCookie(req, res);
      res.json({ ok: true });
    }
  });

  r.get('/yo', (req, res) => {
    if (!req.usuario) return aviso(res, 401, 'Sin sesión', { codigo: 'NO_AUTH' });
    res.json(datosUsuario(req.usuario, req.sesion.csrf));
  });

  // Todo lo que sigue exige sesión, token CSRF y, si aplica, cambio de clave inicial
  r.use(seg.exigirLogin);
  r.use(seg.exigirCsrf);

  r.post('/clave', async (req, res) => {
    const { actual, nueva } = req.body || {};
    const u = db.prepare('SELECT * FROM usuarios WHERE id = ?').get(req.usuario.id);
    if (typeof actual !== 'string' || !(await seg.verificarClave(actual, u.clave_hash))) return aviso(res, 400, 'La clave actual no es correcta');
    const problema = seg.errorClave(nueva, u.usuario);
    if (problema) return aviso(res, 400, problema);
    if (nueva === actual) return aviso(res, 400, 'La nueva clave debe ser diferente a la actual');
    db.prepare('UPDATE usuarios SET clave_hash = ?, debe_cambiar = 0 WHERE id = ?').run(await seg.hashClave(nueva), u.id);
    db.prepare('DELETE FROM sesiones WHERE usuario_id = ? AND token_hash != ?').run(u.id, req.sesion.hash);
    auditar(db, req, 'CLAVE_CAMBIADA', 'usuario', u.id);
    res.json({ ok: true });
  });

  r.get('/esquema', (_req, res) => res.json({ ...esquema.paraCliente(), empresa: emp }));

  /* ---------- Atenciones ---------- */
  const SELECT_ATENCION = `
    SELECT a.*, c.nombre AS creado_por_nombre, m.nombre AS actualizado_por_nombre
      FROM atenciones a
      JOIN usuarios c ON c.id = a.creado_por
      LEFT JOIN usuarios m ON m.id = a.actualizado_por`;

  const hidratar = (f, conFirmas = true) => {
    if (!f) return null;
    const salida = { ...f, datos: JSON.parse(f.datos) };
    if (!conFirmas) { delete salida.firma_trip; delete salida.firma_pac; }
    return salida;
  };

  function condiciones(req, q) {
    const donde = [];
    const args = [];
    if (req.usuario.rol === 'operador') { donde.push('a.creado_por = ?'); args.push(req.usuario.id); }
    if (/^\d{4}-\d{2}-\d{2}$/.test(q.desde || '')) { donde.push('a.fecha >= ?'); args.push(q.desde); }
    if (/^\d{4}-\d{2}-\d{2}$/.test(q.hasta || '')) { donde.push('a.fecha <= ?'); args.push(q.hasta); }
    if (q.evento && esquema.EVENTOS.includes(q.evento)) { donde.push('a.tipo_evento = ?'); args.push(q.evento); }
    if (q.estado === 'activo' || q.estado === 'anulado') { donde.push('a.estado = ?'); args.push(q.estado); }
    const texto = typeof q.q === 'string' ? q.q.trim().slice(0, 60) : '';
    if (texto) {
      const like = `%${escLike(texto)}%`;
      donde.push(`(a.consecutivo LIKE ? ESCAPE '\\' OR a.num_doc LIKE ? ESCAPE '\\' OR a.paciente LIKE ? ESCAPE '\\' OR a.placa LIKE ? ESCAPE '\\')`);
      args.push(like, like, like, like);
    }
    return { sql: donde.length ? 'WHERE ' + donde.join(' AND ') : '', args, texto };
  }

  const filtrosDe = (q) => ({
    desde: /^\d{4}-\d{2}-\d{2}$/.test(q.desde || '') ? q.desde : '',
    hasta: /^\d{4}-\d{2}-\d{2}$/.test(q.hasta || '') ? q.hasta : '',
    evento: esquema.EVENTOS.includes(q.evento) ? q.evento : '',
    estado: q.estado === 'activo' || q.estado === 'anulado' ? q.estado : '',
    q: typeof q.q === 'string' ? q.q.trim().slice(0, 60) : '',
  });

  r.get('/resumen', (req, res) => {
    const solo = req.usuario.rol === 'operador' ? 'AND creado_por = ?' : '';
    const a = req.usuario.rol === 'operador' ? [req.usuario.id] : [];
    const fh = rep.fmtFechaHora(ahora()); // DD/MM/AAAA HH:MM en hora de Colombia
    const hoy = `${fh.slice(6, 10)}-${fh.slice(3, 5)}-${fh.slice(0, 2)}`;
    const mes = hoy.slice(0, 7);
    const n = (sql, ...args) => db.prepare(sql).get(...args, ...a).n;
    res.json({
      hoy: n(`SELECT COUNT(*) n FROM atenciones WHERE estado='activo' AND fecha = ? ${solo}`, hoy),
      mes: n(`SELECT COUNT(*) n FROM atenciones WHERE estado='activo' AND substr(fecha,1,7) = ? ${solo}`, mes),
      total: n(`SELECT COUNT(*) n FROM atenciones WHERE estado='activo' ${solo}`),
      porEvento: db.prepare(`SELECT tipo_evento evento, COUNT(*) n FROM atenciones WHERE estado='activo' AND substr(fecha,1,7) = ? ${solo} GROUP BY tipo_evento ORDER BY n DESC`).all(mes, ...a),
    });
  });

  r.get('/atenciones', (req, res) => {
    const pagina = Math.max(1, parseInt(req.query.pagina, 10) || 1);
    const { sql, args } = condiciones(req, req.query);
    const total = db.prepare(`SELECT COUNT(*) n FROM atenciones a ${sql}`).get(...args).n;
    const items = db.prepare(
      `SELECT a.id, a.consecutivo, a.fecha, a.tipo_evento, a.num_doc, a.paciente, a.placa, a.ips_receptora, a.estado, a.creado_en, c.nombre AS creado_por_nombre
         FROM atenciones a JOIN usuarios c ON c.id = a.creado_por ${sql}
        ORDER BY a.fecha DESC, a.id DESC LIMIT ? OFFSET ?`
    ).all(...args, POR_PAGINA, (pagina - 1) * POR_PAGINA);
    res.json({ items, total, pagina, paginas: Math.max(1, Math.ceil(total / POR_PAGINA)) });
  });

  const imagenValida = (s) => typeof s === 'string' && s.length < 250000 && /^data:image\/(png|jpeg);base64,[A-Za-z0-9+/=]+$/.test(s);

  r.post('/atenciones', seg.exigirRol('admin', 'operador'), (req, res) => {
    const { uuid, datos, firmaTrip, firmaPac } = req.body || {};
    if (typeof uuid !== 'string' || !/^[A-Za-z0-9-]{16,64}$/.test(uuid)) return aviso(res, 400, 'Identificador de registro no válido');

    // Reintentos (por ejemplo, al sincronizar después de estar sin señal): no duplicar
    const previo = db.prepare('SELECT id, consecutivo FROM atenciones WHERE uuid = ?').get(uuid);
    if (previo) return res.json({ id: previo.id, consecutivo: previo.consecutivo, repetido: true });

    const { limpio, errores } = esquema.validar(datos);
    if (!imagenValida(firmaTrip)) errores.firmaTrip = 'La firma del tripulante es obligatoria';
    if (firmaPac && !imagenValida(firmaPac)) errores.firmaPac = 'Firma no válida';
    if (Object.keys(errores).length) return aviso(res, 400, 'Revise los campos marcados', { campos: errores });

    const crear = db.transaction(() => {
      const anio = Number(limpio.fecha.slice(0, 4));
      db.prepare('INSERT INTO contadores (anio, ultimo) VALUES (?, 0) ON CONFLICT(anio) DO NOTHING').run(anio);
      db.prepare('UPDATE contadores SET ultimo = ultimo + 1 WHERE anio = ?').run(anio);
      const n = db.prepare('SELECT ultimo FROM contadores WHERE anio = ?').get(anio).ultimo;
      const consecutivo = `APH-${anio}-${String(n).padStart(6, '0')}`;
      const info = db.prepare(
        `INSERT INTO atenciones (uuid, consecutivo, datos, firma_trip, firma_pac, fecha, tipo_evento, num_doc, paciente, placa, ips_receptora, creado_por, creado_en)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`
      ).run(uuid, consecutivo, JSON.stringify(limpio), firmaTrip, firmaPac || null, limpio.fecha, limpio.tipoEvento, limpio.numDoc,
        `${limpio.nombres} ${limpio.apellidos}`, limpio.placaAmb || null, limpio.ipsReceptora || null, req.usuario.id, ahora());
      auditar(db, req, 'ATENCION_CREADA', 'atencion', info.lastInsertRowid, { consecutivo });
      return { id: Number(info.lastInsertRowid), consecutivo };
    });
    res.status(201).json(crear());
  });

  function cargarAtencion(req, res) {
    const id = parseInt(req.params.id, 10);
    if (!Number.isInteger(id)) { aviso(res, 400, 'Identificador no válido'); return null; }
    const f = db.prepare(`${SELECT_ATENCION} WHERE a.id = ?`).get(id);
    if (!f || (req.usuario.rol === 'operador' && f.creado_por !== req.usuario.id)) { aviso(res, 404, 'Atención no encontrada'); return null; }
    return hidratar(f);
  }

  r.get('/atenciones/:id', (req, res) => {
    const a = cargarAtencion(req, res);
    if (a) res.json(a);
  });

  // Solo el administrador modifica; cada cambio queda con su motivo y la versión anterior
  r.put('/atenciones/:id', seg.exigirRol('admin'), (req, res) => {
    const a = cargarAtencion(req, res);
    if (!a) return;
    const motivo = typeof req.body?.motivo === 'string' ? req.body.motivo.trim() : '';
    if (motivo.length < 5 || motivo.length > 300) return aviso(res, 400, 'Escriba el motivo del cambio (mínimo 5 caracteres)', { campos: { motivo: 'Obligatorio' } });
    const { limpio, errores } = esquema.validar(req.body?.datos);
    if (Object.keys(errores).length) return aviso(res, 400, 'Revise los campos marcados', { campos: errores });

    const cambios = {};
    for (const c of esquema.TODOS) {
      const antes = esquema.texto(a.datos[c.n]);
      const despues = esquema.texto(limpio[c.n]);
      if (antes !== despues) cambios[c.l] = [antes, despues];
    }
    if (!Object.keys(cambios).length) return aviso(res, 400, 'No hay cambios para guardar');

    db.transaction(() => {
      db.prepare('INSERT INTO atenciones_historial (atencion_id, version, datos, cambios, motivo, editado_por, editado_en) VALUES (?,?,?,?,?,?,?)')
        .run(a.id, a.version, JSON.stringify(a.datos), JSON.stringify(cambios), motivo, req.usuario.id, ahora());
      db.prepare(
        `UPDATE atenciones SET datos = ?, fecha = ?, tipo_evento = ?, num_doc = ?, paciente = ?, placa = ?, ips_receptora = ?,
                version = version + 1, actualizado_por = ?, actualizado_en = ? WHERE id = ?`
      ).run(JSON.stringify(limpio), limpio.fecha, limpio.tipoEvento, limpio.numDoc, `${limpio.nombres} ${limpio.apellidos}`,
        limpio.placaAmb || null, limpio.ipsReceptora || null, req.usuario.id, ahora(), a.id);
      auditar(db, req, 'ATENCION_EDITADA', 'atencion', a.id, { consecutivo: a.consecutivo, motivo, cambios });
    })();
    res.json({ ok: true, version: a.version + 1 });
  });

  r.get('/atenciones/:id/historial', seg.exigirRol('admin'), (req, res) => {
    const a = cargarAtencion(req, res);
    if (!a) return;
    const filas = db.prepare(
      `SELECT h.version, h.motivo, h.cambios, h.editado_en, u.nombre editado_por
         FROM atenciones_historial h JOIN usuarios u ON u.id = h.editado_por WHERE h.atencion_id = ? ORDER BY h.id DESC`
    ).all(a.id).map((h) => ({ ...h, cambios: JSON.parse(h.cambios) }));
    res.json(filas);
  });

  const motivoValido = (req) => (typeof req.body?.motivo === 'string' ? req.body.motivo.trim() : '');

  r.post('/atenciones/:id/anular', seg.exigirRol('admin'), (req, res) => {
    const a = cargarAtencion(req, res);
    if (!a) return;
    const motivo = motivoValido(req);
    if (a.estado === 'anulado') return aviso(res, 400, 'La atención ya está anulada');
    if (motivo.length < 5 || motivo.length > 300) return aviso(res, 400, 'Escriba el motivo de la anulación (mínimo 5 caracteres)');
    db.prepare("UPDATE atenciones SET estado='anulado', motivo_anulacion=?, actualizado_por=?, actualizado_en=? WHERE id=?").run(motivo, req.usuario.id, ahora(), a.id);
    auditar(db, req, 'ATENCION_ANULADA', 'atencion', a.id, { consecutivo: a.consecutivo, motivo });
    res.json({ ok: true });
  });

  r.post('/atenciones/:id/reactivar', seg.exigirRol('admin'), (req, res) => {
    const a = cargarAtencion(req, res);
    if (!a) return;
    if (a.estado !== 'anulado') return aviso(res, 400, 'La atención no está anulada');
    db.prepare("UPDATE atenciones SET estado='activo', motivo_anulacion=NULL, actualizado_por=?, actualizado_en=? WHERE id=?").run(req.usuario.id, ahora(), a.id);
    auditar(db, req, 'ATENCION_REACTIVADA', 'atencion', a.id, { consecutivo: a.consecutivo });
    res.json({ ok: true });
  });

  /* ---------- Descargas ---------- */
  const TIPOS = {
    pdf: 'application/pdf',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  };
  function enviar(res, formato, nombre, buffer) {
    res.set({
      'Content-Type': TIPOS[formato],
      'Content-Disposition': `attachment; filename="${nombre}.${formato}"`,
      'Cache-Control': 'no-store',
      'Content-Length': buffer.length,
    });
    res.end(buffer);
  }

  r.get('/atenciones/:id/:formato', async (req, res, next) => {
    const f = req.params.formato;
    if (f !== 'pdf' && f !== 'docx') return next();
    const a = cargarAtencion(req, res);
    if (!a) return;
    try {
      const buf = f === 'pdf' ? await rep.pdfAtencion(a, emp, req.usuario.nombre) : await rep.docxAtencion(a, emp, req.usuario.nombre);
      auditar(db, req, 'DESCARGA_SOPORTE', 'atencion', a.id, { formato: f, consecutivo: a.consecutivo });
      enviar(res, f, `Soporte_${a.consecutivo}`, buf);
    } catch (e) {
      console.error('Error generando soporte:', e);
      aviso(res, 500, 'No se pudo generar el documento');
    }
  });

  r.get('/reportes/atenciones.:formato', seg.exigirRol('admin', 'consulta'), async (req, res, next) => {
    const formato = req.params.formato;
    if (!TIPOS[formato]) return next();
    try {
      const { sql, args } = condiciones(req, req.query);
      const filtros = filtrosDe(req.query);
      const limite = formato === 'xlsx' ? MAX_LISTA_EXCEL : MAX_LISTA_DOCUMENTO;
      const total = db.prepare(`SELECT COUNT(*) n FROM atenciones a ${sql}`).get(...args).n;
      const filas = db.prepare(`${SELECT_ATENCION} ${sql} ORDER BY a.fecha DESC, a.id DESC LIMIT ?`)
        .all(...args, limite).map((f) => hidratar(f, false));
      const truncado = total > filas.length;
      let buf;
      if (formato === 'xlsx') buf = await rep.xlsxLista(filas, filtros, emp, req.usuario.nombre);
      else if (formato === 'pdf') buf = await rep.pdfLista(filas, filtros, emp, req.usuario.nombre, truncado);
      else buf = await rep.docxLista(filas, filtros, emp, req.usuario.nombre, truncado);
      auditar(db, req, 'DESCARGA_REPORTE', 'reporte', null, { formato, filas: filas.length, filtros });
      enviar(res, formato, `Reporte_atenciones_${new Date().toISOString().slice(0, 10)}`, buf);
    } catch (e) {
      console.error('Error generando reporte:', e);
      aviso(res, 500, 'No se pudo generar el reporte');
    }
  });

  /* ---------- Usuarios (solo administrador) ---------- */
  const admin = seg.exigirRol('admin');
  const ROLES = ['admin', 'operador', 'consulta'];
  const cuantosAdminActivos = () => db.prepare("SELECT COUNT(*) n FROM usuarios WHERE rol='admin' AND activo=1").get().n;

  r.get('/usuarios', admin, (_req, res) => {
    res.json(db.prepare('SELECT id, usuario, nombre, rol, activo, debe_cambiar, creado_en, ultimo_acceso, bloqueado_hasta FROM usuarios ORDER BY usuario').all()
      .map((u) => ({ ...u, bloqueado: u.bloqueado_hasta > Date.now() })));
  });

  r.post('/usuarios', admin, async (req, res) => {
    const usuario = String(req.body?.usuario ?? '').trim();
    const nombre = String(req.body?.nombre ?? '').trim();
    const rol = req.body?.rol;
    if (!/^[A-Za-z0-9._-]{3,30}$/.test(usuario)) return aviso(res, 400, 'El usuario debe tener de 3 a 30 letras, números, punto o guion');
    if (nombre.length < 3 || nombre.length > 80) return aviso(res, 400, 'Escriba el nombre completo (de 3 a 80 caracteres)');
    if (!ROLES.includes(rol)) return aviso(res, 400, 'Rol no válido');
    if (db.prepare('SELECT 1 FROM usuarios WHERE usuario = ?').get(usuario)) return aviso(res, 409, 'Ese usuario ya existe');
    const temporal = seg.claveTemporal();
    const info = db.prepare('INSERT INTO usuarios (usuario, nombre, rol, clave_hash, debe_cambiar, creado_en) VALUES (?,?,?,?,1,?)')
      .run(usuario, nombre, rol, await seg.hashClave(temporal), ahora());
    auditar(db, req, 'USUARIO_CREADO', 'usuario', info.lastInsertRowid, { usuario, rol });
    res.status(201).json({ id: Number(info.lastInsertRowid), claveTemporal: temporal });
  });

  r.put('/usuarios/:id', admin, (req, res) => {
    const id = parseInt(req.params.id, 10);
    const u = db.prepare('SELECT * FROM usuarios WHERE id = ?').get(id);
    if (!u) return aviso(res, 404, 'Usuario no encontrado');
    const nombre = req.body?.nombre === undefined ? u.nombre : String(req.body.nombre).trim();
    const rol = req.body?.rol === undefined ? u.rol : req.body.rol;
    const activo = req.body?.activo === undefined ? u.activo : (req.body.activo ? 1 : 0);
    if (nombre.length < 3 || nombre.length > 80) return aviso(res, 400, 'Nombre no válido');
    if (!ROLES.includes(rol)) return aviso(res, 400, 'Rol no válido');
    if (u.id === req.usuario.id && (rol !== 'admin' || !activo)) return aviso(res, 400, 'No puede quitarse a sí mismo el rol de administrador ni desactivar su cuenta');
    if (u.rol === 'admin' && u.activo && (rol !== 'admin' || !activo) && cuantosAdminActivos() <= 1) return aviso(res, 400, 'Debe existir al menos un administrador activo');
    db.prepare('UPDATE usuarios SET nombre=?, rol=?, activo=? WHERE id=?').run(nombre, rol, activo, id);
    if (!activo || rol !== u.rol) db.prepare('DELETE FROM sesiones WHERE usuario_id = ?').run(id);
    if (req.body?.desbloquear) db.prepare('UPDATE usuarios SET intentos=0, bloqueado_hasta=0 WHERE id=?').run(id);
    auditar(db, req, 'USUARIO_EDITADO', 'usuario', id, { usuario: u.usuario, antes: { nombre: u.nombre, rol: u.rol, activo: u.activo }, despues: { nombre, rol, activo } });
    res.json({ ok: true });
  });

  r.post('/usuarios/:id/reiniciar-clave', admin, async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const u = db.prepare('SELECT * FROM usuarios WHERE id = ?').get(id);
    if (!u) return aviso(res, 404, 'Usuario no encontrado');
    const temporal = seg.claveTemporal();
    db.prepare('UPDATE usuarios SET clave_hash=?, debe_cambiar=1, intentos=0, bloqueado_hasta=0 WHERE id=?').run(await seg.hashClave(temporal), id);
    db.prepare('DELETE FROM sesiones WHERE usuario_id = ?').run(id);
    auditar(db, req, 'CLAVE_REINICIADA', 'usuario', id, { usuario: u.usuario });
    res.json({ claveTemporal: temporal });
  });

  /* ---------- Auditoría y respaldos (solo administrador) ---------- */
  r.get('/auditoria', admin, (req, res) => {
    const pagina = Math.max(1, parseInt(req.query.pagina, 10) || 1);
    const por = 50;
    const total = db.prepare('SELECT COUNT(*) n FROM auditoria').get().n;
    const items = db.prepare('SELECT * FROM auditoria ORDER BY id DESC LIMIT ? OFFSET ?').all(por, (pagina - 1) * por);
    res.json({ items, total, pagina, paginas: Math.max(1, Math.ceil(total / por)) });
  });

  r.get('/reportes/auditoria.xlsx', admin, async (req, res) => {
    const filas = db.prepare('SELECT * FROM auditoria ORDER BY id DESC LIMIT 100000').all();
    auditar(db, req, 'DESCARGA_AUDITORIA', 'reporte', null, { filas: filas.length });
    enviar(res, 'xlsx', `Auditoria_${new Date().toISOString().slice(0, 10)}`, await rep.xlsxAuditoria(filas, emp));
  });

  r.get('/respaldos', admin, (_req, res) => res.json(listarRespaldos(config.dirDatos)));

  r.get('/respaldo/descargar', admin, async (req, res) => {
    const tmp = path.join(os.tmpdir(), `aph-respaldo-${Date.now()}.db`);
    try {
      await db.backup(tmp);
      auditar(db, req, 'DESCARGA_RESPALDO', 'base de datos', null);
      res.set({ 'Content-Type': 'application/octet-stream', 'Content-Disposition': `attachment; filename="ips-respaldo-${new Date().toISOString().slice(0, 10)}.db"`, 'Cache-Control': 'no-store' });
      res.sendFile(tmp, (err) => { fs.unlink(tmp, () => {}); if (err && !res.headersSent) res.status(500).end(); });
    } catch (e) {
      fs.unlink(tmp, () => {});
      console.error('Error en respaldo:', e);
      aviso(res, 500, 'No se pudo crear el respaldo');
    }
  });

  r.post('/respaldos', admin, async (req, res) => {
    try {
      await crearRespaldo(db, config.dirDatos);
      auditar(db, req, 'RESPALDO_CREADO', 'base de datos', null);
      res.json(listarRespaldos(config.dirDatos));
    } catch (e) {
      console.error('Error en respaldo:', e);
      aviso(res, 500, 'No se pudo crear el respaldo');
    }
  });

  // Cualquier otra ruta de la API
  r.use((_req, res) => aviso(res, 404, 'No encontrado'));
  // Errores (JSON mal formado, cuerpo muy grande, etc.)
  // eslint-disable-next-line no-unused-vars
  r.use((err, _req, res, _next) => {
    if (err.type === 'entity.too.large') return aviso(res, 413, 'El envío es demasiado grande');
    if (err.type === 'entity.parse.failed') return aviso(res, 400, 'Solicitud mal formada');
    console.error(err);
    aviso(res, 500, 'Error interno del servidor');
  });

  return r;
}

module.exports = { crearRouter };

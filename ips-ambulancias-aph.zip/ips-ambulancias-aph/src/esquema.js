'use strict';
/*
 * ESQUEMA DE CAMPOS DEL REGISTRO DE ATENCIÓN
 * ------------------------------------------
 * Este archivo es la única fuente de verdad: de aquí salen el formulario de la app,
 * la validación del servidor y las columnas de los reportes (PDF, Word y Excel).
 * Para agregar, quitar o renombrar un campo (por ejemplo al ajustar el formato
 * oficial de la IPS) basta con editar este archivo y reiniciar el servidor.
 *
 * Propiedades de cada campo:
 *  n: nombre interno   l: etiqueta visible   t: tipo (text, textarea, date, time, select, number, multi)
 *  req: obligatorio    o: opciones (select y multi)   max: largo máximo   min/max en number
 *  w: ancho en el formulario ('w2' doble, 'full' completo)   up: guardar en mayúsculas
 *  patron: expresión regular que debe cumplir   si: {n, v} solo se muestra si el campo n vale v
 */

const EVENTOS = [
  'Accidente de tránsito', 'Enfermedad general', 'Accidente de trabajo',
  'Evento catastrófico', 'Traslado programado', 'Otro',
];

const SECCIONES = [
  {
    id: 'servicio', titulo: 'Datos del servicio', ayuda: 'Tiempos y móvil',
    campos: [
      { n: 'fecha', l: 'Fecha del servicio', t: 'date', req: true },
      { n: 'hLlamada', l: 'Hora de la llamada', t: 'time', req: true },
      { n: 'hSalida', l: 'Hora de salida', t: 'time' },
      { n: 'hSitio', l: 'Llegada al sitio', t: 'time' },
      { n: 'tipoAmb', l: 'Tipo de ambulancia', t: 'select', req: true, o: ['Básica (TAB)', 'Medicalizada (TAM)'] },
      { n: 'tipoTraslado', l: 'Tipo de traslado', t: 'select', req: true, o: ['Primario (del sitio a la IPS)', 'Secundario (entre instituciones)', 'Redondo'] },
      { n: 'placaAmb', l: 'Placa de la ambulancia', t: 'text', req: true, up: true, max: 8, patron: '^[A-Z0-9]{5,7}$', err: 'Use de 5 a 7 letras o números, sin espacios' },
      { n: 'movil', l: 'Número de móvil', t: 'text', max: 20 },
      { n: 'solicitante', l: 'Quién solicitó el servicio', t: 'select', o: ['Línea 123', 'Paciente o familiar', 'EPS', 'Aseguradora', 'Institución de salud', 'Policía o tránsito', 'Otro'] },
    ],
  },
  {
    id: 'evento', titulo: 'Evento', ayuda: 'Dónde y qué ocurrió',
    campos: [
      { n: 'tipoEvento', l: 'Tipo de evento', t: 'select', req: true, o: EVENTOS },
      { n: 'lugar', l: 'Dirección o lugar del evento', t: 'text', req: true, w: 'w2', max: 200 },
      { n: 'municipio', l: 'Municipio', t: 'text', req: true, max: 80 },
      { n: 'departamento', l: 'Departamento', t: 'text', max: 80 },
      { n: 'zona', l: 'Zona', t: 'select', o: ['Urbana', 'Rural'] },
      // Solo accidentes de tránsito (datos que luego sirven para el cobro al SOAT)
      { n: 'condVictima', l: 'Condición de la víctima', t: 'select', o: ['Conductor', 'Pasajero', 'Peatón', 'Ciclista', 'Motociclista'], si: { n: 'tipoEvento', v: 'Accidente de tránsito' } },
      { n: 'placaVehiculo', l: 'Placa del vehículo involucrado', t: 'text', up: true, max: 8, patron: '^[A-Z0-9]{5,7}$', err: 'Use de 5 a 7 letras o números, sin espacios', si: { n: 'tipoEvento', v: 'Accidente de tránsito' } },
      { n: 'aseguradora', l: 'Aseguradora SOAT', t: 'text', max: 80, si: { n: 'tipoEvento', v: 'Accidente de tránsito' } },
      { n: 'poliza', l: 'Número de póliza SOAT', t: 'text', max: 40, si: { n: 'tipoEvento', v: 'Accidente de tránsito' } },
      { n: 'estadoSoat', l: 'Estado del aseguramiento', t: 'select', o: ['Asegurado', 'No asegurado', 'Vehículo fantasma', 'Póliza falsa'], si: { n: 'tipoEvento', v: 'Accidente de tránsito' } },
      { n: 'autoridad', l: 'Autoridad que conoció el hecho', t: 'text', max: 80, si: { n: 'tipoEvento', v: 'Accidente de tránsito' } },
    ],
  },
  {
    id: 'paciente', titulo: 'Paciente', ayuda: 'Identificación y afiliación',
    campos: [
      { n: 'tipoDoc', l: 'Tipo de documento', t: 'select', req: true, o: ['CC', 'TI', 'RC', 'CE', 'PPT', 'PA', 'Sin identificar'] },
      { n: 'numDoc', l: 'Número de documento', t: 'text', req: true, max: 20, patron: '^[A-Za-z0-9]{1,20}$', err: 'Solo letras y números, sin puntos ni espacios (escriba 0 si no se identificó)' },
      { n: 'nombres', l: 'Nombres', t: 'text', req: true, max: 80 },
      { n: 'apellidos', l: 'Apellidos', t: 'text', req: true, max: 80 },
      { n: 'sexo', l: 'Sexo', t: 'select', o: ['Femenino', 'Masculino', 'Indeterminado'] },
      { n: 'fechaNac', l: 'Fecha de nacimiento', t: 'date' },
      { n: 'edad', l: 'Edad (años)', t: 'number', min: 0, max: 120 },
      { n: 'telefono', l: 'Teléfono', t: 'text', max: 20 },
      { n: 'direccion', l: 'Dirección de residencia', t: 'text', w: 'w2', max: 200 },
      { n: 'eps', l: 'EPS', t: 'text', max: 80 },
      { n: 'regimen', l: 'Régimen', t: 'select', o: ['Contributivo', 'Subsidiado', 'Especial', 'Particular', 'No afiliado'] },
      { n: 'acompNombre', l: 'Nombre del acompañante', t: 'text', max: 120 },
      { n: 'acompParentesco', l: 'Parentesco', t: 'text', max: 40 },
      { n: 'acompTel', l: 'Teléfono del acompañante', t: 'text', max: 20 },
    ],
  },
  {
    id: 'valoracion', titulo: 'Valoración inicial', ayuda: 'Al llegar al sitio',
    campos: [
      { n: 'motivo', l: 'Motivo de consulta o relato del evento', t: 'textarea', req: true, w: 'full', max: 2000 },
      { n: 'ta', l: 'TA (mmHg)', t: 'text', max: 7, patron: '^[0-9]{2,3}/[0-9]{2,3}$', err: 'Formato 120/80', v: true },
      { n: 'fc', l: 'FC (lpm)', t: 'number', min: 0, max: 300, v: true },
      { n: 'fr', l: 'FR (rpm)', t: 'number', min: 0, max: 100, v: true },
      { n: 'temp', l: 'Temperatura (°C)', t: 'number', min: 25, max: 45, dec: true, v: true },
      { n: 'spo2', l: 'SpO2 (%)', t: 'number', min: 0, max: 100, v: true },
      { n: 'gluco', l: 'Glucometría (mg/dL)', t: 'number', min: 0, max: 1000, v: true },
      { n: 'glasgow', l: 'Glasgow (3 a 15)', t: 'number', min: 3, max: 15, v: true },
      { n: 'conciencia', l: 'Estado de conciencia', t: 'select', o: ['Alerta', 'Responde a la voz', 'Responde al dolor', 'Inconsciente'] },
      { n: 'hallazgos', l: 'Hallazgos al examen físico', t: 'textarea', w: 'w2', max: 2000 },
      { n: 'diagnostico', l: 'Impresión diagnóstica', t: 'text', req: true, w: 'w2', max: 200 },
      { n: 'cie10', l: 'Código CIE-10', t: 'text', up: true, max: 8, patron: '^[A-Z][0-9]{2}(\\.?[0-9A-Z]{1,3})?$', err: 'Ejemplo: S06.0' },
    ],
  },
  {
    id: 'procedimientos', titulo: 'Procedimientos en el traslado', ayuda: 'Lo que se hizo al paciente',
    campos: [
      { n: 'procedimientos', l: 'Procedimientos realizados', t: 'multi', w: 'full', o: ['Inmovilización', 'Collar cervical', 'Oxígeno', 'Canalización venosa', 'Control de hemorragia', 'Curación', 'Monitoreo', 'Manejo de vía aérea', 'RCP', 'Desfibrilación'] },
      { n: 'insumos', l: 'Medicamentos e insumos usados', t: 'textarea', w: 'w2', max: 2000, ph: 'Nombre, dosis, vía y cantidad' },
      { n: 'evolucion', l: 'Evolución durante el traslado', t: 'textarea', w: 'w2', max: 2000 },
    ],
  },
  {
    id: 'entrega', titulo: 'Entrega del paciente', ayuda: 'Institución que recibe',
    campos: [
      { n: 'ipsReceptora', l: 'Institución que recibe', t: 'text', req: true, w: 'w2', max: 120 },
      { n: 'hLlegadaIps', l: 'Hora de llegada a la institución', t: 'time' },
      { n: 'hEntrega', l: 'Hora de entrega', t: 'time' },
      { n: 'recibeNombre', l: 'Profesional que recibe', t: 'text', max: 120 },
      { n: 'recibeRegistro', l: 'Registro o cargo de quien recibe', t: 'text', max: 80 },
      { n: 'estadoEntrega', l: 'Estado a la entrega', t: 'select', o: ['Estable', 'Mejorado', 'Igual', 'Deteriorado', 'Fallecido en el traslado'] },
      { n: 'desenlace', l: 'Desenlace del servicio', t: 'select', o: ['Trasladado', 'Atendido en el sitio sin traslado', 'Rechazó el traslado', 'Fallecido en el sitio', 'Servicio cancelado'] },
      { n: 'observaciones', l: 'Observaciones', t: 'textarea', w: 'full', max: 2000 },
    ],
  },
  {
    id: 'tripulacion', titulo: 'Tripulación', ayuda: 'Quién prestó el servicio',
    campos: [
      { n: 'conductor', l: 'Conductor', t: 'text', req: true, max: 120 },
      { n: 'tripulante', l: 'Auxiliar o tecnólogo APH', t: 'text', req: true, max: 120 },
      { n: 'medico', l: 'Médico (si es medicalizada)', t: 'text', max: 120 },
      { n: 'docFirmante', l: 'Documento de quien firma el soporte', t: 'text', max: 20 },
      { n: 'motivoSinFirma', l: 'Si el paciente no firma, motivo', t: 'text', w: 'w2', max: 200 },
    ],
  },
];

const TODOS = SECCIONES.flatMap((s) => s.campos);
const POR_NOMBRE = Object.fromEntries(TODOS.map((c) => [c.n, c]));

// Un campo está visible si no depende de otro o si el otro tiene el valor esperado.
function visible(campo, datos) {
  return !campo.si || datos[campo.si.n] === campo.si.v;
}

/**
 * Valida y limpia los datos recibidos. Descarta campos desconocidos y ocultos.
 * Devuelve { limpio, errores } donde errores es { campo: mensaje }.
 */
function validar(entrada) {
  const limpio = {};
  const errores = {};
  const src = entrada && typeof entrada === 'object' ? entrada : {};

  for (const c of TODOS) {
    if (!visible(c, { ...src })) continue;
    let v = src[c.n];

    if (c.t === 'multi') {
      const arr = Array.isArray(v) ? v : [];
      const malos = arr.filter((x) => !c.o.includes(x));
      if (malos.length) errores[c.n] = 'Opción no válida';
      else if (arr.length) limpio[c.n] = [...new Set(arr)];
      if (c.req && !arr.length) errores[c.n] = 'Obligatorio';
      continue;
    }

    if (v === undefined || v === null) v = '';
    if (typeof v === 'number') v = String(v);
    if (typeof v !== 'string') { errores[c.n] = 'Valor no válido'; continue; }
    v = v.trim().replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
    if (c.up) v = v.toUpperCase();

    if (v === '') {
      if (c.req) errores[c.n] = 'Obligatorio';
      continue;
    }

    const max = c.t === 'textarea' ? (c.max || 2000) : (c.max || 200);
    if (c.t !== 'number' && v.length > max) { errores[c.n] = `Máximo ${max} caracteres`; continue; }

    if (c.t === 'select' && !c.o.includes(v)) { errores[c.n] = 'Opción no válida'; continue; }
    if (c.t === 'date') {
      const d = new Date(v + 'T00:00:00Z');
      if (!/^\d{4}-\d{2}-\d{2}$/.test(v) || isNaN(d) || d.toISOString().slice(0, 10) !== v) { errores[c.n] = 'Fecha no válida'; continue; }
    }
    if (c.t === 'time' && !/^([01]\d|2[0-3]):[0-5]\d$/.test(v)) { errores[c.n] = 'Hora no válida'; continue; }
    if (c.t === 'number') {
      const num = Number(v.replace(',', '.'));
      if (!Number.isFinite(num) || num < c.min || num > c.max) { errores[c.n] = `Debe estar entre ${c.min} y ${c.max}`; continue; }
      if (!c.dec && !Number.isInteger(num)) { errores[c.n] = 'Debe ser un número entero'; continue; }
      v = String(num);
    }
    if (c.patron && !new RegExp(c.patron).test(v)) { errores[c.n] = c.err || 'Formato no válido'; continue; }

    limpio[c.n] = v;
  }
  return { limpio, errores };
}

// Texto legible de un valor (para reportes y auditoría)
function texto(valor) {
  if (Array.isArray(valor)) return valor.join(', ');
  return valor === undefined || valor === null ? '' : String(valor);
}

// Esquema que se envía al navegador (sin nada sensible)
function paraCliente() {
  return { secciones: SECCIONES, eventos: EVENTOS };
}

module.exports = { SECCIONES, TODOS, POR_NOMBRE, EVENTOS, validar, visible, texto, paraCliente };

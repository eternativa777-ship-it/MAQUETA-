'use strict';
const crypto = require('crypto');
const { promisify } = require('util');

const scrypt = promisify(crypto.scrypt);
const N = 16384, R = 8, P = 1, LARGO = 64;

/* ---------------- Claves ---------------- */
async function hashClave(clave) {
  const sal = crypto.randomBytes(16);
  const llave = await scrypt(clave, sal, LARGO, { N, r: R, p: P });
  return ['scrypt', N, R, P, sal.toString('base64'), llave.toString('base64')].join('$');
}

async function verificarClave(clave, guardado) {
  const partes = String(guardado || '').split('$');
  if (partes.length !== 6 || partes[0] !== 'scrypt') return false;
  const llave = Buffer.from(partes[5], 'base64');
  const calc = await scrypt(clave, Buffer.from(partes[4], 'base64'), llave.length, { N: +partes[1], r: +partes[2], p: +partes[3] });
  return crypto.timingSafeEqual(calc, llave);
}

// Para que responder a un usuario inexistente tarde lo mismo que uno existente
let hashFalso = null;
async function gastarTiempo(clave) {
  if (!hashFalso) hashFalso = await hashClave(crypto.randomBytes(12).toString('hex'));
  await verificarClave(clave, hashFalso);
}

const COMUNES = new Set([
  'password12', 'contrasena1', 'contraseña1', '1234567890', '12345678910', 'qwerty1234', 'admin12345',
  'ambulancia1', 'ambulancia123', 'colombia123', 'bogota12345', 'abc1234567', 'password123',
]);

function errorClave(clave, usuario) {
  if (typeof clave !== 'string') return 'Clave no válida';
  if (clave.length < 10) return 'La clave debe tener al menos 10 caracteres';
  if (clave.length > 128) return 'La clave es demasiado larga (máximo 128)';
  if (!/\p{L}/u.test(clave) || !/[0-9]/.test(clave)) return 'La clave debe combinar letras y números';
  if (usuario && clave.toLowerCase().includes(String(usuario).toLowerCase())) return 'La clave no debe contener el nombre de usuario';
  if (COMUNES.has(clave.toLowerCase())) return 'Esa clave es demasiado común, elija otra';
  return null;
}

const ALFABETO = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
function claveTemporal() {
  for (;;) {
    let c = '';
    for (let i = 0; i < 12; i++) c += ALFABETO[crypto.randomInt(ALFABETO.length)];
    if (!errorClave(c)) return c;
  }
}

/* ---------------- Sesiones ---------------- */
const sha = (t) => crypto.createHash('sha256').update(t).digest('hex');

function leerCookies(req) {
  const salida = {};
  for (const par of String(req.headers.cookie || '').split(';')) {
    const i = par.indexOf('=');
    if (i < 1) continue;
    try { salida[par.slice(0, i).trim()] = decodeURIComponent(par.slice(i + 1).trim()); } catch { /* cookie mal formada */ }
  }
  return salida;
}

const nombreCookie = (req) => (req.secure ? '__Host-sid' : 'sid');

function crearSesion(db, usuarioId, req, horas) {
  const token = crypto.randomBytes(32).toString('base64url');
  const csrf = crypto.randomBytes(24).toString('base64url');
  const ahora = Date.now();
  db.prepare('DELETE FROM sesiones WHERE expira < ?').run(ahora);
  db.prepare('INSERT INTO sesiones (token_hash, usuario_id, csrf, creada, expira, ip, agente) VALUES (?,?,?,?,?,?,?)')
    .run(sha(token), usuarioId, csrf, ahora, ahora + horas * 3600 * 1000, req.ip, String(req.get('user-agent') || '').slice(0, 200));
  return { token, csrf, maxAge: horas * 3600 * 1000 };
}

function ponerCookie(req, res, token, maxAge) {
  res.cookie(nombreCookie(req), token, { httpOnly: true, sameSite: 'strict', secure: !!req.secure, path: '/', maxAge });
}
function quitarCookie(req, res) {
  res.clearCookie(nombreCookie(req), { httpOnly: true, sameSite: 'strict', secure: !!req.secure, path: '/' });
}

function cargarSesion(db) {
  const buscar = db.prepare(
    `SELECT s.token_hash, s.csrf, s.expira, u.id, u.usuario, u.nombre, u.rol, u.debe_cambiar
       FROM sesiones s JOIN usuarios u ON u.id = s.usuario_id
      WHERE s.token_hash = ? AND s.expira > ? AND u.activo = 1`
  );
  return (req, _res, next) => {
    const c = leerCookies(req);
    const token = c['__Host-sid'] || c.sid;
    if (token) {
      const f = buscar.get(sha(token), Date.now());
      if (f) {
        req.sesion = { hash: f.token_hash, csrf: f.csrf };
        req.usuario = { id: f.id, usuario: f.usuario, nombre: f.nombre, rol: f.rol, debe_cambiar: !!f.debe_cambiar };
      }
    }
    next();
  };
}

/* ---------------- Guardas ---------------- */
const LIBRES_SI_DEBE_CAMBIAR = new Set(['/yo', '/clave', '/logout']);

function exigirLogin(req, res, next) {
  if (!req.usuario) return res.status(401).json({ error: 'Debe iniciar sesión', codigo: 'NO_AUTH' });
  if (req.usuario.debe_cambiar && !LIBRES_SI_DEBE_CAMBIAR.has(req.path)) {
    return res.status(403).json({ error: 'Debe cambiar su clave antes de continuar', codigo: 'CAMBIAR_CLAVE' });
  }
  next();
}

const exigirRol = (...roles) => (req, res, next) => {
  if (!req.usuario || !roles.includes(req.usuario.rol)) return res.status(403).json({ error: 'No tiene permiso para esta acción', codigo: 'SIN_PERMISO' });
  next();
};

const METODOS_SEGUROS = new Set(['GET', 'HEAD', 'OPTIONS']);

function exigirCsrf(req, res, next) {
  if (METODOS_SEGUROS.has(req.method) || !req.sesion) return next();
  const enviado = Buffer.from(String(req.get('x-csrf-token') || ''));
  const esperado = Buffer.from(req.sesion.csrf);
  if (enviado.length !== esperado.length || !crypto.timingSafeEqual(enviado, esperado)) {
    return res.status(403).json({ error: 'Sesión no válida, recargue la página', codigo: 'CSRF' });
  }
  next();
}

// Rechaza peticiones que digan venir de otro sitio web
function verificarOrigen(req, res, next) {
  if (METODOS_SEGUROS.has(req.method)) return next();
  const origen = req.get('origin');
  if (!origen) return next();
  let host;
  try { host = new URL(origen).host; } catch { return res.status(403).json({ error: 'Origen no permitido' }); }
  if (host !== req.get('host') && host !== req.host) return res.status(403).json({ error: 'Origen no permitido' });
  next();
}

module.exports = {
  hashClave, verificarClave, gastarTiempo, errorClave, claveTemporal,
  crearSesion, ponerCookie, quitarCookie, cargarSesion, leerCookies, sha,
  exigirLogin, exigirRol, exigirCsrf, verificarOrigen,
};

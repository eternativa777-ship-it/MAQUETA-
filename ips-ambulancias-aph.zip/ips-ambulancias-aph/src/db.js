'use strict';
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

function abrir(dirDatos) {
  fs.mkdirSync(dirDatos, { recursive: true });
  const db = new Database(path.join(dirDatos, 'ips.db'));
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');

  db.exec(`
    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY,
      usuario TEXT NOT NULL UNIQUE COLLATE NOCASE,
      nombre TEXT NOT NULL,
      rol TEXT NOT NULL CHECK (rol IN ('admin','operador','consulta')),
      clave_hash TEXT NOT NULL,
      activo INTEGER NOT NULL DEFAULT 1,
      debe_cambiar INTEGER NOT NULL DEFAULT 1,
      intentos INTEGER NOT NULL DEFAULT 0,
      bloqueado_hasta INTEGER NOT NULL DEFAULT 0,
      creado_en TEXT NOT NULL,
      ultimo_acceso TEXT
    );

    CREATE TABLE IF NOT EXISTS sesiones (
      token_hash TEXT PRIMARY KEY,
      usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
      csrf TEXT NOT NULL,
      creada INTEGER NOT NULL,
      expira INTEGER NOT NULL,
      ip TEXT,
      agente TEXT
    );

    CREATE TABLE IF NOT EXISTS atenciones (
      id INTEGER PRIMARY KEY,
      uuid TEXT NOT NULL UNIQUE,
      consecutivo TEXT NOT NULL UNIQUE,
      datos TEXT NOT NULL,
      firma_trip TEXT,
      firma_pac TEXT,
      fecha TEXT NOT NULL,
      tipo_evento TEXT NOT NULL,
      num_doc TEXT NOT NULL,
      paciente TEXT NOT NULL,
      placa TEXT,
      ips_receptora TEXT,
      estado TEXT NOT NULL DEFAULT 'activo' CHECK (estado IN ('activo','anulado')),
      motivo_anulacion TEXT,
      version INTEGER NOT NULL DEFAULT 1,
      creado_por INTEGER NOT NULL REFERENCES usuarios(id),
      creado_en TEXT NOT NULL,
      actualizado_por INTEGER REFERENCES usuarios(id),
      actualizado_en TEXT
    );
    CREATE INDEX IF NOT EXISTS ix_atenciones_fecha ON atenciones(fecha);
    CREATE INDEX IF NOT EXISTS ix_atenciones_doc ON atenciones(num_doc);
    CREATE INDEX IF NOT EXISTS ix_atenciones_creador ON atenciones(creado_por);

    CREATE TABLE IF NOT EXISTS atenciones_historial (
      id INTEGER PRIMARY KEY,
      atencion_id INTEGER NOT NULL REFERENCES atenciones(id),
      version INTEGER NOT NULL,
      datos TEXT NOT NULL,
      cambios TEXT NOT NULL,
      motivo TEXT NOT NULL,
      editado_por INTEGER NOT NULL REFERENCES usuarios(id),
      editado_en TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS contadores (
      anio INTEGER PRIMARY KEY,
      ultimo INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS auditoria (
      id INTEGER PRIMARY KEY,
      fecha TEXT NOT NULL,
      usuario_id INTEGER,
      usuario TEXT,
      accion TEXT NOT NULL,
      entidad TEXT,
      entidad_id TEXT,
      detalle TEXT,
      ip TEXT
    );
    CREATE INDEX IF NOT EXISTS ix_auditoria_fecha ON auditoria(fecha);
  `);
  return db;
}

function auditar(db, req, accion, entidad, entidadId, detalle, usuarioForzado) {
  const u = usuarioForzado || (req && req.usuario) || null;
  db.prepare(
    `INSERT INTO auditoria (fecha, usuario_id, usuario, accion, entidad, entidad_id, detalle, ip)
     VALUES (?,?,?,?,?,?,?,?)`
  ).run(
    new Date().toISOString(),
    u ? u.id : null,
    u ? u.usuario : null,
    accion,
    entidad || null,
    entidadId === undefined || entidadId === null ? null : String(entidadId),
    detalle === undefined ? null : (typeof detalle === 'string' ? detalle : JSON.stringify(detalle)),
    req ? req.ip : null
  );
}

// ---------- Respaldos automáticos ----------
async function crearRespaldo(db, dirDatos, conservar = 14) {
  const dir = path.join(dirDatos, 'respaldos');
  fs.mkdirSync(dir, { recursive: true });
  const sello = new Date().toISOString().replace(/[:.]/g, '-');
  const destino = path.join(dir, `ips-${sello}.db`);
  await db.backup(destino);
  const archivos = fs.readdirSync(dir).filter((f) => /^ips-.*\.db$/.test(f)).sort();
  while (archivos.length > conservar) fs.unlinkSync(path.join(dir, archivos.shift()));
  return destino;
}

function listarRespaldos(dirDatos) {
  const dir = path.join(dirDatos, 'respaldos');
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir)
    .filter((f) => /^ips-.*\.db$/.test(f))
    .map((f) => ({ archivo: f, bytes: fs.statSync(path.join(dir, f)).size, fecha: fs.statSync(path.join(dir, f)).mtime.toISOString() }))
    .sort((a, b) => b.fecha.localeCompare(a.fecha));
}

function iniciarRespaldosAutomaticos(db, dirDatos) {
  const hacer = () => crearRespaldo(db, dirDatos).catch((e) => console.error('No se pudo crear el respaldo:', e.message));
  const ultimo = listarRespaldos(dirDatos)[0];
  if (!ultimo || Date.now() - new Date(ultimo.fecha).getTime() > 20 * 3600 * 1000) hacer();
  const t = setInterval(hacer, 24 * 3600 * 1000);
  t.unref();
}

module.exports = { abrir, auditar, crearRespaldo, listarRespaldos, iniciarRespaldosAutomaticos };

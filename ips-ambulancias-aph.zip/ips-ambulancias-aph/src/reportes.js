'use strict';
const PDFDocument = require('pdfkit');
const ExcelJS = require('exceljs');
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, ShadingType,
  BorderStyle, AlignmentType, ImageRun, Footer, PageNumber, PageOrientation, VerticalAlign,
} = require('docx');
const { SECCIONES, TODOS, EVENTOS, visible, texto } = require('./esquema');

const TZ = 'America/Bogota';
const COL = { teal: '#0F6E6E', red: '#C4161C', ink: '#102A33', soft: '#4B6470', line: '#C9D6DB', zebra: '#F2F6F7' };

/* ---------------- Utilidades ---------------- */
function partesFecha(iso) {
  const f = new Intl.DateTimeFormat('es-CO', {
    timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false,
  });
  const o = {};
  for (const p of f.formatToParts(new Date(iso))) o[p.type] = p.value;
  if (o.hour === '24') o.hour = '00';
  return o;
}
const fmtFechaHora = (iso) => { if (!iso) return ''; const p = partesFecha(iso); return `${p.day}/${p.month}/${p.year} ${p.hour}:${p.minute}`; };
const fmtFecha = (ymd) => (/^\d{4}-\d{2}-\d{2}$/.test(ymd || '') ? `${ymd.slice(8, 10)}/${ymd.slice(5, 7)}/${ymd.slice(0, 4)}` : (ymd || ''));

function dataUrl(s) {
  const m = /^data:image\/(png|jpeg);base64,([A-Za-z0-9+/=]+)$/.exec(s || '');
  return m ? { tipo: m[1] === 'jpeg' ? 'jpg' : 'png', buf: Buffer.from(m[2], 'base64') } : null;
}

// Las fuentes estándar de PDF solo dibujan Latin-1; lo demás se reemplaza para no romper el texto.
const limpiarPdf = (s) => String(s ?? '').replace(/[^\u0009\u000A\u0020-\u00FF\u2018\u2019\u201C\u201D\u2022\u2013\u2014\u2026\u20AC]/g, '?');

// Campos con valor y visibles, agrupados por sección
function camposConValor(datos) {
  const salida = [];
  for (const s of SECCIONES) {
    const items = s.campos
      .filter((c) => visible(c, datos) && texto(datos[c.n]) !== '')
      .map((c) => {
        let v = texto(datos[c.n]);
        if (c.t === 'date') v = fmtFecha(v);
        return { c, v };
      });
    if (items.length) salida.push({ s, items });
  }
  return salida;
}

function filtrosTexto(f) {
  const partes = [];
  if (f.desde) partes.push(`desde ${fmtFecha(f.desde)}`);
  if (f.hasta) partes.push(`hasta ${fmtFecha(f.hasta)}`);
  if (f.evento) partes.push(`evento: ${f.evento}`);
  if (f.estado) partes.push(`estado: ${f.estado}`);
  if (f.q) partes.push(`búsqueda: "${f.q}"`);
  return partes.length ? partes.join(' · ') : 'Sin filtros (todas las atenciones)';
}

function resumir(filas) {
  const activas = filas.filter((r) => r.estado === 'activo');
  const porEvento = {};
  for (const r of activas) porEvento[r.tipo_evento] = (porEvento[r.tipo_evento] || 0) + 1;
  return { total: filas.length, activas: activas.length, anuladas: filas.length - activas.length, porEvento };
}

/* =====================================================================
 *  PDF
 * ===================================================================== */
function finalizarPdf(doc) {
  return new Promise((resolve, reject) => {
    const partes = [];
    doc.on('data', (c) => partes.push(c));
    doc.on('end', () => resolve(Buffer.concat(partes)));
    doc.on('error', reject);
    doc.end();
  });
}

function bandaRoja(doc) {
  const w = doc.page.width;
  for (let x = 0, i = 0; x < w; x += 18, i++) {
    doc.rect(x, 0, 18, 8).fill(i % 2 === 0 ? COL.red : '#FFFFFF');
  }
}

function piePdf(doc, izquierda, anulado) {
  const rango = doc.bufferedPageRange();
  for (let i = 0; i < rango.count; i++) {
    doc.switchToPage(i);
    const mg = doc.page.margins;
    const bajo = mg.bottom;
    doc.page.margins.bottom = 0;
    const ancho = doc.page.width - mg.left - mg.right;
    const y = doc.page.height - 30;
    doc.moveTo(mg.left, y - 6).lineTo(mg.left + ancho, y - 6).lineWidth(0.5).strokeColor(COL.line).stroke();
    doc.font('Helvetica').fontSize(7.5).fillColor(COL.soft);
    doc.text(limpiarPdf(izquierda), mg.left, y, { width: ancho - 80, lineBreak: false });
    doc.text(`Página ${i + 1} de ${rango.count}`, mg.left + ancho - 80, y, { width: 80, align: 'right', lineBreak: false });
    if (anulado) {
      doc.save();
      const cx = doc.page.width / 2, cy = doc.page.height / 2;
      doc.rotate(-32, { origin: [cx, cy] });
      doc.fillColor(COL.red).fillOpacity(0.11).font('Helvetica-Bold').fontSize(96)
        .text('ANULADO', 0, cy - 50, { width: doc.page.width, align: 'center', lineBreak: false });
      doc.restore();
    }
    doc.page.margins.bottom = bajo;
  }
}

async function pdfAtencion(a, emp, generadoPor) {
  const doc = new PDFDocument({
    size: 'A4', margins: { top: 34, bottom: 52, left: 40, right: 40 }, bufferPages: true,
    info: { Title: `Soporte ${a.consecutivo}`, Author: emp.nombre, Subject: 'Soporte de atención y traslado' },
  });
  const anchoUtil = doc.page.width - 80;
  const limiteY = () => doc.page.height - doc.page.margins.bottom;

  bandaRoja(doc);
  doc.font('Helvetica-Bold').fontSize(14).fillColor(COL.ink).text(limpiarPdf(emp.nombre), 40, 26, { width: anchoUtil - 170 });
  doc.font('Helvetica').fontSize(8.5).fillColor(COL.soft).text(limpiarPdf(emp.nit ? `NIT ${emp.nit}` : ''), 40, doc.y, { width: anchoUtil - 170 });
  const yCaja = 24;
  doc.roundedRect(40 + anchoUtil - 160, yCaja, 160, 34, 3).lineWidth(1.4).strokeColor(COL.red).stroke();
  doc.font('Helvetica-Bold').fontSize(11).fillColor(COL.red).text(limpiarPdf(a.consecutivo), 40 + anchoUtil - 160, yCaja + 6, { width: 160, align: 'center' });
  doc.font('Helvetica').fontSize(7.5).fillColor(COL.soft).text(`Registrado ${fmtFechaHora(a.creado_en)}`, 40 + anchoUtil - 160, yCaja + 21, { width: 160, align: 'center' });

  doc.y = Math.max(doc.y, 66) + 10;
  doc.font('Helvetica-Bold').fontSize(17).fillColor(COL.ink).text('Soporte de atención y traslado', 40, doc.y);
  doc.moveDown(0.15);
  const metas = [`Registrado por ${a.creado_por_nombre || ''}`];
  if (a.version > 1) metas.push(`Versión ${a.version} (editada por el administrador)`);
  doc.font('Helvetica').fontSize(8.5).fillColor(COL.soft).text(limpiarPdf(metas.join(' · ')), 40, doc.y);
  if (a.estado === 'anulado') {
    doc.moveDown(0.3);
    doc.font('Helvetica-Bold').fontSize(9.5).fillColor(COL.red).text(limpiarPdf(`ANULADO: ${a.motivo_anulacion || 'sin motivo registrado'}`), 40, doc.y, { width: anchoUtil });
  }
  doc.moveDown(0.6);

  const gutter = 16;
  const colW = (anchoUtil - gutter) / 2; // se usa más abajo para las firmas
  // Rejilla de 6 unidades: dato corto = 2 (un tercio), medio = 3 (mitad), largo = 6 (ancho completo)
  const unidades = (it) => {
    if (it.c.t === 'textarea' || it.c.t === 'multi' || it.c.w === 'full' || it.v.length > 58) return 6;
    if (it.c.w === 'w2' || it.v.length > 27) return 3;
    return 2;
  };

  for (const { s, items } of camposConValor(a.datos)) {
    if (doc.y + 70 > limiteY()) doc.addPage();
    doc.font('Helvetica-Bold').fontSize(11).fillColor(COL.teal).text(limpiarPdf(s.titulo), 40, doc.y);
    const yl = doc.y + 1;
    doc.moveTo(40, yl).lineTo(40 + anchoUtil, yl).lineWidth(0.7).strokeColor(COL.teal).stroke();
    doc.y = yl + 6;

    // empacar los datos en filas de 6 unidades
    const filas = [];
    let fila = [], usadas = 0;
    for (const it of items) {
      const u = unidades(it);
      if (usadas + u > 6) { filas.push(fila); fila = []; usadas = 0; }
      fila.push({ ...it, desde: usadas, u });
      usadas += u;
    }
    if (fila.length) filas.push(fila);

    for (const f of filas) {
      doc.font('Helvetica').fontSize(9.5);
      const ancho = (it) => (it.u / 6) * anchoUtil - 12;
      const h = Math.max(...f.map((it) => 11 + doc.heightOfString(limpiarPdf(it.v), { width: ancho(it) })));
      if (doc.y + h > limiteY()) doc.addPage();
      const y = doc.y;
      f.forEach((it) => {
        const x = 40 + (it.desde / 6) * anchoUtil;
        doc.font('Helvetica').fontSize(7.5).fillColor(COL.soft).text(limpiarPdf(it.c.l), x, y, { width: ancho(it), lineBreak: false, ellipsis: true });
        doc.font('Helvetica').fontSize(9.5).fillColor(COL.ink).text(limpiarPdf(it.v), x, y + 10, { width: ancho(it) });
      });
      doc.y = y + h + 4;
    }
    doc.moveDown(0.3);
  }

  // Firmas
  if (doc.y + 140 > limiteY()) doc.addPage();
  doc.font('Helvetica-Bold').fontSize(11).fillColor(COL.teal).text('Firmas', 40, doc.y);
  const yf = doc.y + 1;
  doc.moveTo(40, yf).lineTo(40 + anchoUtil, yf).lineWidth(0.7).strokeColor(COL.teal).stroke();
  const yImg = yf + 10;
  const firmas = [
    { img: dataUrl(a.firma_trip), rotulo: 'Tripulante responsable', nombre: a.datos.tripulante },
    { img: dataUrl(a.firma_pac), rotulo: 'Paciente o acompañante', nombre: a.datos.acompNombre || [a.datos.nombres, a.datos.apellidos].filter(Boolean).join(' ') },
  ];
  firmas.forEach((f, i) => {
    const x = 40 + i * (colW + gutter);
    if (f.img) { try { doc.image(f.img.buf, x + 4, yImg, { fit: [colW - 8, 72], align: 'center' }); } catch { /* imagen dañada: se deja el espacio */ } }
    doc.moveTo(x, yImg + 78).lineTo(x + colW, yImg + 78).lineWidth(0.6).strokeColor(COL.ink).stroke();
    doc.font('Helvetica-Bold').fontSize(8.5).fillColor(COL.ink).text(limpiarPdf(f.rotulo), x, yImg + 82, { width: colW, lineBreak: false });
    doc.font('Helvetica').fontSize(8.5).fillColor(COL.soft).text(limpiarPdf(f.nombre || ''), x, yImg + 93, { width: colW, lineBreak: false });
  });
  doc.y = yImg + 110;

  piePdf(doc, `${a.consecutivo} · Generado el ${fmtFechaHora(new Date().toISOString())} por ${generadoPor}`, a.estado === 'anulado');
  return finalizarPdf(doc);
}

async function pdfLista(filas, filtros, emp, generadoPor, truncado) {
  const doc = new PDFDocument({
    size: 'A4', layout: 'landscape', margins: { top: 34, bottom: 50, left: 36, right: 36 }, bufferPages: true,
    info: { Title: 'Reporte de atenciones', Author: emp.nombre },
  });
  const ancho = doc.page.width - 72;
  const limiteY = () => doc.page.height - doc.page.margins.bottom;

  bandaRoja(doc);
  doc.font('Helvetica-Bold').fontSize(14).fillColor(COL.ink).text(limpiarPdf(emp.nombre), 36, 24);
  doc.font('Helvetica').fontSize(8.5).fillColor(COL.soft).text(limpiarPdf(emp.nit ? `NIT ${emp.nit}` : ''), 36, doc.y);
  doc.font('Helvetica-Bold').fontSize(16).fillColor(COL.ink).text('Reporte de atenciones', 36, doc.y + 6);
  doc.font('Helvetica').fontSize(8.5).fillColor(COL.soft).text(limpiarPdf(`Filtros: ${filtrosTexto(filtros)}`), 36, doc.y + 2, { width: ancho });

  const r = resumir(filas);
  doc.moveDown(0.6);
  doc.font('Helvetica-Bold').fontSize(10).fillColor(COL.teal).text('Resumen', 36, doc.y);
  const lineaResumen = `Total: ${r.total}   ·   Activas: ${r.activas}   ·   Anuladas: ${r.anuladas}`;
  doc.font('Helvetica').fontSize(9).fillColor(COL.ink).text(lineaResumen, 36, doc.y + 2);
  const tipos = Object.entries(r.porEvento).sort((x, y) => y[1] - x[1]).map(([k, v]) => `${k}: ${v}`).join('   ·   ');
  if (tipos) doc.text(limpiarPdf(`Por tipo de evento (activas):  ${tipos}`), 36, doc.y + 2, { width: ancho });
  if (truncado) doc.fillColor(COL.red).text(limpiarPdf(`Se muestran solo las primeras ${filas.length} atenciones. Ajuste los filtros o use el reporte de Excel para ver todas.`), 36, doc.y + 2, { width: ancho });
  doc.moveDown(0.8);

  const cols = [
    ['Consecutivo', 104, (x) => x.consecutivo], ['Fecha', 58, (x) => fmtFecha(x.fecha)], ['Paciente', 150, (x) => x.paciente],
    ['Documento', 88, (x) => `${x.datos.tipoDoc || ''} ${x.num_doc}`], ['Evento', 112, (x) => x.tipo_evento], ['Placa', 56, (x) => x.placa || ''],
    ['Institución que recibe', 142, (x) => x.ips_receptora || ''], ['Estado', 60, (x) => (x.estado === 'anulado' ? 'ANULADO' : 'Activo')],
  ];
  const total = cols.reduce((s, c) => s + c[1], 0);
  const esc = ancho / total;
  const anchos = cols.map((c) => c[1] * esc);

  const encabezado = () => {
    const y = doc.y;
    doc.rect(36, y, ancho, 17).fill(COL.teal);
    let x = 36;
    cols.forEach((c, i) => { doc.font('Helvetica-Bold').fontSize(8).fillColor('#FFFFFF').text(c[0], x + 4, y + 5, { width: anchos[i] - 8, lineBreak: false }); x += anchos[i]; });
    doc.y = y + 17;
  };
  encabezado();

  filas.forEach((f, idx) => {
    doc.font('Helvetica').fontSize(8);
    const celdas = cols.map((c) => limpiarPdf(c[2](f)));
    const h = Math.max(...celdas.map((t, i) => doc.heightOfString(t, { width: anchos[i] - 8 }))) + 7;
    if (doc.y + h > limiteY()) { doc.addPage(); encabezado(); }
    const y = doc.y;
    if (idx % 2 === 1) doc.rect(36, y, ancho, h).fill(COL.zebra);
    let x = 36;
    celdas.forEach((t, i) => {
      doc.font('Helvetica').fontSize(8).fillColor(f.estado === 'anulado' ? COL.red : COL.ink).text(t, x + 4, y + 3.5, { width: anchos[i] - 8 });
      x += anchos[i];
    });
    doc.y = y + h;
  });
  if (!filas.length) doc.font('Helvetica').fontSize(10).fillColor(COL.soft).text('No hay atenciones que coincidan con los filtros.', 36, doc.y + 12);

  piePdf(doc, `Reporte de atenciones · Generado el ${fmtFechaHora(new Date().toISOString())} por ${generadoPor}`, false);
  return finalizarPdf(doc);
}

/* =====================================================================
 *  WORD (.docx)
 * ===================================================================== */
const FUENTE = 'Arial';
const borde = { style: BorderStyle.SINGLE, size: 4, color: 'C9D6DB' };
const bordes = { top: borde, bottom: borde, left: borde, right: borde };

function parrafosTexto(t, opts = {}) {
  return String(t ?? '').split('\n').map((linea) => new Paragraph({
    spacing: { before: 20, after: 20 },
    alignment: opts.centro ? AlignmentType.CENTER : AlignmentType.LEFT,
    children: [new TextRun({ text: linea, font: FUENTE, size: opts.size || 19, bold: !!opts.bold, color: opts.color || '102A33' })],
  }));
}

function celda(t, ancho, opts = {}) {
  return new TableCell({
    width: { size: ancho, type: WidthType.DXA },
    columnSpan: opts.span,
    borders: bordes,
    verticalAlign: VerticalAlign.CENTER,
    margins: { top: 50, bottom: 50, left: 90, right: 90 },
    shading: opts.sombra ? { type: ShadingType.CLEAR, fill: opts.sombra, color: 'auto' } : undefined,
    children: opts.hijos || parrafosTexto(t, opts),
  });
}

function titulo(t) {
  return new Paragraph({
    spacing: { before: 260, after: 90 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 8, color: '0F6E6E', space: 2 } },
    keepNext: true,
    children: [new TextRun({ text: t, font: FUENTE, size: 24, bold: true, color: '0F6E6E' })],
  });
}

function pieDocx(txt) {
  return new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.LEFT,
      children: [
        new TextRun({ text: `${txt}   ·   Página `, font: FUENTE, size: 15, color: '4B6470' }),
        new TextRun({ children: [PageNumber.CURRENT], font: FUENTE, size: 15, color: '4B6470' }),
        new TextRun({ text: ' de ', font: FUENTE, size: 15, color: '4B6470' }),
        new TextRun({ children: [PageNumber.TOTAL_PAGES], font: FUENTE, size: 15, color: '4B6470' }),
      ],
    })],
  });
}

const estilosBase = { default: { document: { run: { font: FUENTE, size: 19 } } } };

async function docxAtencion(a, emp, generadoPor) {
  const ANCHO = 9906; // A4 con márgenes de 1000
  const cLab = 1900, cVal = 3053;
  const hijos = [];

  hijos.push(new Paragraph({ children: [new TextRun({ text: emp.nombre, font: FUENTE, size: 30, bold: true, color: '102A33' })] }));
  if (emp.nit) hijos.push(new Paragraph({ children: [new TextRun({ text: `NIT ${emp.nit}`, font: FUENTE, size: 17, color: '4B6470' })] }));
  hijos.push(new Paragraph({ spacing: { before: 160 }, children: [new TextRun({ text: 'Soporte de atención y traslado', font: FUENTE, size: 38, bold: true, color: '0F6E6E' })] }));
  hijos.push(new Paragraph({ children: [
    new TextRun({ text: a.consecutivo, font: FUENTE, size: 24, bold: true, color: 'C4161C' }),
    new TextRun({ text: `     Registrado ${fmtFechaHora(a.creado_en)} por ${a.creado_por_nombre || ''}`, font: FUENTE, size: 17, color: '4B6470' }),
  ] }));
  if (a.version > 1) hijos.push(new Paragraph({ children: [new TextRun({ text: `Versión ${a.version} (editada por el administrador)`, font: FUENTE, size: 17, color: '4B6470' })] }));
  if (a.estado === 'anulado') hijos.push(new Paragraph({ spacing: { before: 80 }, children: [new TextRun({ text: `ANULADO: ${a.motivo_anulacion || 'sin motivo registrado'}`, font: FUENTE, size: 21, bold: true, color: 'C4161C' })] }));

  for (const { s, items } of camposConValor(a.datos)) {
    hijos.push(titulo(s.titulo));
    const esAncha = (it) => it.c.t === 'textarea' || it.c.t === 'multi' || it.c.w === 'full' || it.v.length > 48;
    const filas = [];
    let par = [];
    for (const it of items) {
      if (esAncha(it)) {
        if (par.length) { filas.push(par); par = []; }
        filas.push([it]);
      } else { par.push(it); if (par.length === 2) { filas.push(par); par = []; } }
    }
    if (par.length) filas.push(par);

    const rows = filas.map((fila) => {
      const celdas = [];
      fila.forEach((it) => {
        celdas.push(celda(it.c.l, cLab, { sombra: 'EAF2F2', size: 16, color: '4B6470', bold: true }));
        celdas.push(esAncha(it) ? celda(it.v, ANCHO - cLab, { span: 3 }) : celda(it.v, cVal));
      });
      if (fila.length === 1 && !esAncha(fila[0])) celdas.push(celda('', cLab, { sombra: 'EAF2F2' }), celda('', cVal));
      return new TableRow({ cantSplit: true, children: celdas });
    });
    hijos.push(new Table({ width: { size: ANCHO, type: WidthType.DXA }, columnWidths: [cLab, cVal, cLab, cVal], rows }));
  }

  hijos.push(titulo('Firmas'));
  const mitad = ANCHO / 2;
  const bloqueFirma = (f, rotulo, nombre) => {
    const kids = [];
    if (f) kids.push(new Paragraph({ alignment: AlignmentType.CENTER, children: [new ImageRun({ type: f.tipo, data: f.buf, transformation: { width: 210, height: 75 } })] }));
    else kids.push(new Paragraph({ children: [new TextRun({ text: ' ', size: 60 })] }));
    kids.push(...parrafosTexto(rotulo, { bold: true, size: 17, centro: true }));
    kids.push(...parrafosTexto(nombre || '', { size: 17, color: '4B6470', centro: true }));
    return kids;
  };
  hijos.push(new Table({
    width: { size: ANCHO, type: WidthType.DXA }, columnWidths: [mitad, mitad],
    rows: [new TableRow({ cantSplit: true, children: [
      celda('', mitad, { hijos: bloqueFirma(dataUrl(a.firma_trip), 'Tripulante responsable', a.datos.tripulante) }),
      celda('', mitad, { hijos: bloqueFirma(dataUrl(a.firma_pac), 'Paciente o acompañante', a.datos.acompNombre || [a.datos.nombres, a.datos.apellidos].filter(Boolean).join(' ')) }),
    ] })],
  }));

  const doc = new Document({
    creator: emp.nombre, title: `Soporte ${a.consecutivo}`, styles: estilosBase,
    sections: [{
      properties: { page: { size: { width: 11906, height: 16838 }, margin: { top: 900, bottom: 900, left: 1000, right: 1000 } } },
      footers: { default: pieDocx(`${a.consecutivo} · Generado el ${fmtFechaHora(new Date().toISOString())} por ${generadoPor}`) },
      children: hijos,
    }],
  });
  return Packer.toBuffer(doc);
}

async function docxLista(filas, filtros, emp, generadoPor, truncado) {
  const ANCHO = 15398; // A4 horizontal con márgenes de 720
  const cols = [
    ['Consecutivo', 2000, (x) => x.consecutivo], ['Fecha', 1150, (x) => fmtFecha(x.fecha)], ['Paciente', 2900, (x) => x.paciente],
    ['Documento', 1600, (x) => `${x.datos.tipoDoc || ''} ${x.num_doc}`], ['Evento', 2100, (x) => x.tipo_evento], ['Placa', 1000, (x) => x.placa || ''],
    ['Institución que recibe', 3648, (x) => x.ips_receptora || ''], ['Estado', 1000, (x) => (x.estado === 'anulado' ? 'ANULADO' : 'Activo')],
  ];
  const r = resumir(filas);
  const hijos = [
    new Paragraph({ children: [new TextRun({ text: emp.nombre, font: FUENTE, size: 30, bold: true })] }),
    ...(emp.nit ? [new Paragraph({ children: [new TextRun({ text: `NIT ${emp.nit}`, font: FUENTE, size: 17, color: '4B6470' })] })] : []),
    new Paragraph({ spacing: { before: 140 }, children: [new TextRun({ text: 'Reporte de atenciones', font: FUENTE, size: 36, bold: true, color: '0F6E6E' })] }),
    new Paragraph({ children: [new TextRun({ text: `Filtros: ${filtrosTexto(filtros)}`, font: FUENTE, size: 17, color: '4B6470' })] }),
    titulo('Resumen'),
    new Paragraph({ children: [new TextRun({ text: `Total: ${r.total}   ·   Activas: ${r.activas}   ·   Anuladas: ${r.anuladas}`, font: FUENTE, size: 19 })] }),
  ];
  const tipos = Object.entries(r.porEvento).sort((x, y) => y[1] - x[1]);
  if (tipos.length) {
    hijos.push(new Paragraph({ spacing: { before: 60 }, children: [new TextRun({ text: 'Por tipo de evento (activas): ' + tipos.map(([k, v]) => `${k}: ${v}`).join('   ·   '), font: FUENTE, size: 19 })] }));
  }
  if (truncado) hijos.push(new Paragraph({ children: [new TextRun({ text: `Se muestran solo las primeras ${filas.length} atenciones. Ajuste los filtros o use el reporte de Excel para ver todas.`, font: FUENTE, size: 18, bold: true, color: 'C4161C' })] }));
  hijos.push(titulo('Detalle'));

  const encabezado = new TableRow({
    tableHeader: true, cantSplit: true,
    children: cols.map((c) => celda(c[0], c[1], { sombra: '0F6E6E', color: 'FFFFFF', bold: true, size: 17 })),
  });
  const cuerpo = filas.map((f, i) => new TableRow({
    cantSplit: true,
    children: cols.map((c) => celda(c[2](f), c[1], { size: 16, sombra: i % 2 ? 'F2F6F7' : undefined, color: f.estado === 'anulado' ? 'C4161C' : '102A33' })),
  }));
  if (!filas.length) hijos.push(new Paragraph({ children: [new TextRun({ text: 'No hay atenciones que coincidan con los filtros.', font: FUENTE, size: 19, color: '4B6470' })] }));
  else hijos.push(new Table({ width: { size: ANCHO, type: WidthType.DXA }, columnWidths: cols.map((c) => c[1]), rows: [encabezado, ...cuerpo] }));

  const doc = new Document({
    creator: emp.nombre, title: 'Reporte de atenciones', styles: estilosBase,
    sections: [{
      properties: { page: { size: { width: 11906, height: 16838, orientation: PageOrientation.LANDSCAPE }, margin: { top: 720, bottom: 720, left: 720, right: 720 } } },
      footers: { default: pieDocx(`Reporte de atenciones · Generado el ${fmtFechaHora(new Date().toISOString())} por ${generadoPor}`) },
      children: hijos,
    }],
  });
  return Packer.toBuffer(doc);
}

/* =====================================================================
 *  EXCEL (.xlsx)
 * ===================================================================== */
const FUENTE_XL = { name: 'Arial', size: 10 };

function fechaExcel(ymd) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(ymd || '')) return null;
  return new Date(Date.UTC(+ymd.slice(0, 4), +ymd.slice(5, 7) - 1, +ymd.slice(8, 10)));
}

async function xlsxLista(filas, filtros, emp, generadoPor) {
  const wb = new ExcelJS.Workbook();
  wb.creator = emp.nombre;
  wb.created = new Date();

  const ws = wb.addWorksheet('Atenciones', { views: [{ state: 'frozen', xSplit: 1, ySplit: 1 }] });
  const columnas = [
    { h: 'Consecutivo', w: 22, f: (x) => x.consecutivo },
    { h: 'Estado', w: 10, f: (x) => x.estado },
    { h: 'Registrado en', w: 17, f: (x) => fmtFechaHora(x.creado_en) },
    { h: 'Registrado por', w: 22, f: (x) => x.creado_por_nombre || '' },
    { h: 'Versión', w: 9, f: (x) => x.version, num: true },
    { h: 'Motivo de anulación', w: 26, f: (x) => x.motivo_anulacion || '' },
  ];
  for (const c of TODOS) {
    columnas.push({
      h: c.l, campo: c,
      w: Math.min(42, Math.max(12, c.l.length + 3, c.t === 'textarea' ? 34 : 0)),
      f: (x) => {
        const v = x.datos[c.n];
        if (c.t === 'date') return fechaExcel(v);
        if (c.t === 'number' && v !== undefined && v !== '') return Number(v);
        return texto(v);
      },
    });
  }
  ws.columns = columnas.map((c) => ({ header: c.h, width: c.w }));
  for (const f of filas) ws.addRow(columnas.map((c) => c.f(f)));

  const ultima = ws.rowCount;
  ws.getRow(1).height = 32;
  ws.getRow(1).eachCell((cel) => {
    cel.font = { ...FUENTE_XL, bold: true, color: { argb: 'FFFFFFFF' } };
    cel.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0F6E6E' } };
    cel.alignment = { vertical: 'middle', wrapText: true };
  });
  for (let i = 2; i <= ultima; i++) {
    const fila = ws.getRow(i);
    fila.eachCell({ includeEmpty: true }, (cel, n) => {
      cel.font = { ...FUENTE_XL, ...(filas[i - 2]?.estado === 'anulado' ? { color: { argb: 'FFC4161C' } } : {}) };
      cel.alignment = { vertical: 'top', wrapText: !!columnas[n - 1]?.campo && columnas[n - 1].campo.t === 'textarea' };
      if (columnas[n - 1]?.campo?.t === 'date') cel.numFmt = 'dd/mm/yyyy';
    });
  }
  ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: columnas.length } };

  // ---- Hoja Resumen con fórmulas que se recalculan si se edita la hoja Atenciones ----
  const rs = wb.addWorksheet('Resumen');
  rs.columns = [{ width: 38 }, { width: 14 }, { width: 14 }];
  const ini = 2, fin = Math.max(ultima, 2);
  const L = (nombre) => ws.getColumn(columnas.findIndex((c) => c.campo && c.campo.n === nombre) + 1).letter;
  const rango = (letra) => `Atenciones!$${letra}$${ini}:$${letra}$${fin}`;
  const colEstado = rango('B');
  const colEvento = rango(L('tipoEvento'));
  const colFecha = rango(L('fecha'));
  const colIps = rango(L('ipsReceptora'));
  const r = resumir(filas);

  const negrita = { ...FUENTE_XL, bold: true };
  let fila = 1;
  const t = rs.getCell(`A${fila}`); t.value = emp.nombre; t.font = { name: 'Arial', size: 14, bold: true };
  fila++; rs.getCell(`A${fila}`).value = 'Resumen de atenciones'; rs.getCell(`A${fila}`).font = { name: 'Arial', size: 11, bold: true, color: { argb: 'FF0F6E6E' } };
  fila++; rs.getCell(`A${fila}`).value = `Filtros: ${filtrosTexto(filtros)}`; rs.getCell(`A${fila}`).font = FUENTE_XL;
  fila++; rs.getCell(`A${fila}`).value = `Generado el ${fmtFechaHora(new Date().toISOString())} por ${generadoPor}`; rs.getCell(`A${fila}`).font = FUENTE_XL;
  fila += 2;

  const encabezar = (fi, etiquetas) => etiquetas.forEach((e, i) => {
    const c = rs.getCell(fi, i + 1); c.value = e; c.font = { ...FUENTE_XL, bold: true, color: { argb: 'FFFFFFFF' } };
    c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0F6E6E' } };
  });

  encabezar(fila, ['Concepto', 'Cantidad']); fila++;
  const totales = [
    ['Total de atenciones', `COUNTA(${rango('A')})`, r.total],
    ['Activas', `COUNTIF(${colEstado},"activo")`, r.activas],
    ['Anuladas', `COUNTIF(${colEstado},"anulado")`, r.anuladas],
  ];
  for (const [et, fo, res] of totales) {
    rs.getCell(fila, 1).value = et; rs.getCell(fila, 1).font = FUENTE_XL;
    rs.getCell(fila, 2).value = { formula: filas.length ? fo : '0', result: res }; rs.getCell(fila, 2).font = FUENTE_XL;
    fila++;
  }
  fila++;

  encabezar(fila, ['Por tipo de evento (solo activas)', 'Cantidad']); fila++;
  for (const ev of EVENTOS) {
    rs.getCell(fila, 1).value = ev; rs.getCell(fila, 1).font = FUENTE_XL;
    rs.getCell(fila, 2).value = { formula: `COUNTIFS(${colEvento},$A${fila},${colEstado},"activo")`, result: r.porEvento[ev] || 0 };
    rs.getCell(fila, 2).font = FUENTE_XL;
    fila++;
  }
  fila++;

  const meses = {};
  const ips = {};
  for (const f of filas.filter((x) => x.estado === 'activo')) {
    meses[f.fecha.slice(0, 7)] = (meses[f.fecha.slice(0, 7)] || 0) + 1;
    if (f.ips_receptora) ips[f.ips_receptora] = (ips[f.ips_receptora] || 0) + 1;
  }
  encabezar(fila, ['Por mes (solo activas)', 'Cantidad']); fila++;
  for (const m of Object.keys(meses).sort()) {
    const [anio, mes] = m.split('-').map(Number);
    rs.getCell(fila, 1).value = new Date(Date.UTC(anio, mes - 1, 1)); rs.getCell(fila, 1).numFmt = 'mmmm yyyy'; rs.getCell(fila, 1).font = FUENTE_XL;
    rs.getCell(fila, 1).alignment = { horizontal: 'left' };
    rs.getCell(fila, 2).value = {
      formula: `COUNTIFS(${colFecha},">="&$A${fila},${colFecha},"<"&EDATE($A${fila},1),${colEstado},"activo")`, result: meses[m],
    };
    rs.getCell(fila, 2).font = FUENTE_XL;
    fila++;
  }
  fila++;

  const topIps = Object.entries(ips).sort((a, b) => b[1] - a[1]).slice(0, 25);
  encabezar(fila, ['Instituciones que reciben (solo activas)', 'Cantidad']); fila++;
  for (const [nombre, n] of topIps) {
    rs.getCell(fila, 1).value = nombre; rs.getCell(fila, 1).font = FUENTE_XL;
    rs.getCell(fila, 2).value = { formula: `COUNTIFS(${colIps},$A${fila},${colEstado},"activo")`, result: n };
    rs.getCell(fila, 2).font = FUENTE_XL;
    fila++;
  }

  return Buffer.from(await wb.xlsx.writeBuffer());
}

async function xlsxAuditoria(filas, emp) {
  const wb = new ExcelJS.Workbook();
  wb.creator = emp.nombre;
  const ws = wb.addWorksheet('Auditoría', { views: [{ state: 'frozen', ySplit: 1 }] });
  ws.columns = [
    { header: 'Fecha y hora', width: 18 }, { header: 'Usuario', width: 18 }, { header: 'Acción', width: 24 },
    { header: 'Entidad', width: 14 }, { header: 'Id', width: 10 }, { header: 'Detalle', width: 70 }, { header: 'IP', width: 18 },
  ];
  for (const f of filas) ws.addRow([fmtFechaHora(f.fecha), f.usuario || '', f.accion, f.entidad || '', f.entidad_id || '', f.detalle || '', f.ip || '']);
  ws.getRow(1).eachCell((c) => {
    c.font = { ...FUENTE_XL, bold: true, color: { argb: 'FFFFFFFF' } };
    c.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0F6E6E' } };
  });
  for (let i = 2; i <= ws.rowCount; i++) ws.getRow(i).eachCell({ includeEmpty: true }, (c) => { c.font = FUENTE_XL; c.alignment = { vertical: 'top', wrapText: true }; });
  ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: 7 } };
  return Buffer.from(await wb.xlsx.writeBuffer());
}

module.exports = { pdfAtencion, pdfLista, docxAtencion, docxLista, xlsxLista, xlsxAuditoria, fmtFechaHora, fmtFecha };

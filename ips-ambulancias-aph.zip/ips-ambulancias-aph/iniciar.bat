@echo off
rem Inicia el sistema en Windows. Requiere Node.js 20 o superior (https://nodejs.org).
cd /d "%~dp0"
if not exist node_modules (
  echo Instalando componentes por primera vez...
  call npm install --omit=dev
)
echo.
echo Abra en el navegador:  http://localhost:3000
echo Para detener el sistema cierre esta ventana.
echo.
node server.js
pause

(() => {
'use strict';

/* =====================================================================
 *  Registro de atención y traslado - aplicación web instalable (PWA)
 *  Todo el contenido dinámico se arma con textContent (nunca innerHTML)
 *  para que un dato malicioso no pueda ejecutar código.
 * ===================================================================== */
const ROLES = { admin: 'Administrador', operador: 'Tripulación', consulta: 'Consulta' };
const estado = {
  yo: null, csrf: '', esquema: null, instalar: null, sinRed: false,
  filtros: { q: '', desde: '', hasta: '', evento: '', estado: '', pagina: 1 },
};
const raiz = document.getElementById('app');

/* ---------------- Utilidades ---------------- */
function h(tag, attrs, ...hijos) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'value' || k === 'checked' || k === 'disabled' || k === 'hidden' || k === 'selected') el[k] = v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  for (const c of hijos.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c.nodeType ? c : document.createTextNode(String(c)));
  }
  return el;
}
const pad = (n) => String(n).padStart(2, '0');
const hoyLocal = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const horaLocal = () => { const d = new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const fmtFecha = (y) => (/^\d{4}-\d{2}-\d{2}$/.test(y || '') ? `${y.slice(8, 10)}/${y.slice(5, 7)}/${y.slice(0, 4)}` : (y || ''));
const formateador = new Intl.DateTimeFormat('es-CO', { timeZone: 'America/Bogota', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false });
function fmtFechaHora(iso) {
  if (!iso) return '';
  const o = {};
  formateador.formatToParts(new Date(iso)).forEach((p) => { o[p.type] = p.value; });
  return `${o.day}/${o.month}/${o.year} ${o.hour === '24' ? '00' : o.hour}:${o.minute}`;
}
function uuid() {
  if (crypto.randomUUID) return crypto.randomUUID();
  const b = crypto.getRandomValues(new Uint8Array(16));
  b[6] = (b[6] & 15) | 64; b[8] = (b[8] & 63) | 128;
  const x = [...b].map((v) => v.toString(16).padStart(2, '0')).join('');
  return `${x.slice(0, 8)}-${x.slice(8, 12)}-${x.slice(12, 16)}-${x.slice(16, 20)}-${x.slice(20)}`;
}
let temporizadorToast;
function aviso(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(temporizadorToast);
  temporizadorToast = setTimeout(() => { t.hidden = true; }, 4200);
}
function cruz() {
  const d = document.createElement('div');
  d.innerHTML = '<svg viewBox="0 0 100 100" aria-hidden="true"><rect width="100" height="100" rx="22" fill="#C4161C"/><path d="M39 20h22v19h19v22H61v19H39V61H20V39h19z" fill="#fff"/></svg>';
  return d.firstChild;
}

/* ---------------- Comunicación con el servidor ---------------- */
async function api(metodo, ruta, cuerpo) {
  const opt = { method: metodo, headers: {}, credentials: 'same-origin' };
  if (cuerpo !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(cuerpo); }
  if (metodo !== 'GET' && !estado.csrf && estado.yo && ruta !== '/login') await recuperar();
  if (metodo !== 'GET' && estado.csrf) opt.headers['X-CSRF-Token'] = estado.csrf;
  let r;
  try { r = await fetch('/api' + ruta, opt); } catch { const e = new Error('Sin conexión con el servidor'); e.red = true; throw e; }
  const datos = (r.headers.get('content-type') || '').includes('json') ? await r.json().catch(() => null) : null;
  if (!r.ok) {
    const e = new Error((datos && datos.error) || `Error ${r.status}`);
    e.status = r.status; e.codigo = datos && datos.codigo; e.campos = datos && datos.campos;
    if (r.status === 401 && ruta !== '/login' && ruta !== '/yo') sesionVencida();
    throw e;
  }
  return datos;
}

async function descargar(ruta) {
  let r;
  try { r = await fetch('/api' + ruta, { credentials: 'same-origin' }); } catch { aviso('Sin conexión: no se pudo descargar'); return; }
  if (!r.ok) {
    const d = await r.json().catch(() => null);
    if (r.status === 401) sesionVencida(); else aviso((d && d.error) || 'No se pudo descargar el archivo');
    return;
  }
  const nombre = /filename="?([^";]+)"?/.exec(r.headers.get('content-disposition') || '')?.[1] || 'archivo';
  const url = URL.createObjectURL(await r.blob());
  const a = h('a', { href: url, download: nombre });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

/* ---------------- Cola de envío sin señal ---------------- */
const CLAVE_COLA = 'aph_cola_v1';
const leerCola = () => { try { return JSON.parse(localStorage.getItem(CLAVE_COLA) || '[]'); } catch { return []; } };
const guardarCola = (c) => { try { localStorage.setItem(CLAVE_COLA, JSON.stringify(c)); return true; } catch { return false; } };
const misPendientes = () => (estado.yo ? leerCola().filter((i) => i.usuarioId === estado.yo.usuario.id) : []);
function encolar(item, uid) {
  const c = leerCola(); c.push({ ...item, usuarioId: uid, guardado: new Date().toISOString() });
  const ok = guardarCola(c);
  actualizarInsignia();
  return ok;
}
let sincronizando = false;
async function sincronizar(manual) {
  if (sincronizando || !estado.yo || estado.yo.debeCambiar) return;
  const pendientes = misPendientes().filter((i) => !i.rechazada);
  if (!pendientes.length) return;
  sincronizando = true;
  let enviadas = 0;
  try {
    if (!estado.csrf) { const d = await api('GET', '/yo'); estado.csrf = d.csrf; estado.sinRed = false; }
    for (const item of pendientes) {
      try {
        await api('POST', '/atenciones', { uuid: item.uuid, datos: item.datos, firmaTrip: item.firmaTrip, firmaPac: item.firmaPac });
        guardarCola(leerCola().filter((x) => x.uuid !== item.uuid));
        enviadas++;
      } catch (e) {
        if (e.red || e.status === 401 || e.status >= 500) break;
        guardarCola(leerCola().map((x) => (x.uuid === item.uuid ? { ...x, rechazada: e.message } : x)));
      }
    }
  } catch { /* sin red o sin sesión: se reintenta luego */ } finally { sincronizando = false; }
  if (enviadas) aviso(`${enviadas} ${enviadas === 1 ? 'atención enviada' : 'atenciones enviadas'} al servidor`);
  else if (manual) aviso('Todavía no hay conexión con el servidor');
  actualizarInsignia();
  if (enviadas && /^#\/(inicio|registros)?$/.test(location.hash || '#/')) render();
}

function actualizarInsignia() {
  const p = document.getElementById('insignia');
  if (!p) return;
  const n = misPendientes().length;
  const sinRed = !navigator.onLine || estado.sinRed;
  p.className = 'pastilla' + (!sinRed && !n ? ' ok' : '');
  p.textContent = n ? `${n} sin enviar${sinRed ? ' · sin conexión' : ''}` : (sinRed ? 'Sin conexión' : 'En línea');
  p.disabled = !n;
  p.title = n ? 'Toque para intentar enviar ahora' : '';
}

/* ---------------- Firma manuscrita ---------------- */
function crearFirma(rotulo, ayuda, requerida) {
  const lienzo = h('canvas', { class: 'lienzo', role: 'img', 'aria-label': `Área de firma: ${rotulo}` });
  const ctx = lienzo.getContext('2d');
  let vacia = true, dibujando = false;
  const err = h('span', { class: 'err' });
  function ajustar() {
    const r = lienzo.getBoundingClientRect();
    if (!r.width) return;
    const previa = vacia ? null : lienzo.toDataURL();
    const dpr = window.devicePixelRatio || 1;
    lienzo.width = Math.round(r.width * dpr); lienzo.height = Math.round(r.height * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.lineWidth = 2.4; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#102A33';
    if (previa) { const i = new Image(); i.onload = () => ctx.drawImage(i, 0, 0, r.width, r.height); i.src = previa; }
  }
  if (window.ResizeObserver) new ResizeObserver(ajustar).observe(lienzo); else window.addEventListener('resize', ajustar);
  const pos = (e) => { const r = lienzo.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
  lienzo.addEventListener('pointerdown', (e) => { dibujando = true; lienzo.setPointerCapture(e.pointerId); const [x, y] = pos(e); ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 0.01, y); ctx.stroke(); vacia = false; wrap.classList.remove('invalida'); err.textContent = ''; });
  lienzo.addEventListener('pointermove', (e) => { if (!dibujando) return; const [x, y] = pos(e); ctx.lineTo(x, y); ctx.stroke(); });
  ['pointerup', 'pointercancel'].forEach((ev) => lienzo.addEventListener(ev, () => { dibujando = false; }));
  const limpiar = () => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, lienzo.width, lienzo.height); ctx.restore(); vacia = true; };
  const wrap = h('div', { class: 'firma-caja campo' },
    h('span', { class: 'et' }, rotulo, requerida ? h('span', { class: 'req' }, ' *') : null),
    lienzo,
    h('div', { class: 'pie' }, h('span', {}, ayuda), h('button', { type: 'button', class: 'enlace', onclick: limpiar }, 'Borrar firma')),
    err);
  return {
    el: wrap,
    vacia: () => vacia,
    limpiar,
    error(msg) { wrap.classList.add('invalida'); err.textContent = msg; },
    dato() {
      if (vacia) return '';
      const o = document.createElement('canvas'); o.width = 420; o.height = 150;
      const c = o.getContext('2d'); c.fillStyle = '#fff'; c.fillRect(0, 0, 420, 150); c.drawImage(lienzo, 0, 0, 420, 150);
      return o.toDataURL('image/jpeg', 0.6);
    },
  };
}

/* ---------------- Formulario generado desde el esquema del servidor ---------------- */
function todosLosCampos() { return estado.esquema.secciones.flatMap((s) => s.campos); }

function crearControl(c, valor) {
  const id = 'f_' + c.n;
  const err = h('span', { class: 'err' });
  const wrap = h('div', { class: ['campo', c.w || '', c.up ? 'mayus' : ''].join(' ').trim() });
  const req = c.req ? h('span', { class: 'req' }, ' *') : null;
  let entradas, leer;
  if (c.t === 'multi') {
    const cajas = c.o.map((op) => h('input', { type: 'checkbox', value: op, checked: (valor || []).includes(op) }));
    entradas = cajas;
    leer = () => cajas.filter((i) => i.checked).map((i) => i.value);
    wrap.append(h('span', { class: 'et' }, c.l, req), h('div', { class: 'checks', role: 'group', 'aria-label': c.l }, cajas.map((i) => h('label', { class: 'chip' }, i, i.value))), err);
  } else {
    let e;
    if (c.t === 'select') e = h('select', { id }, h('option', { value: '' }, 'Seleccione'), c.o.map((o) => h('option', { value: o }, o)));
    else if (c.t === 'textarea') e = h('textarea', { id, maxlength: c.max || 2000, placeholder: c.ph });
    else {
      e = h('input', {
        id, type: c.t === 'number' ? 'number' : c.t, autocomplete: 'off', placeholder: c.ph,
        maxlength: c.t === 'text' ? c.max : null, min: c.t === 'number' ? c.min : null, max: c.t === 'number' ? c.max : null,
        step: c.t === 'number' ? (c.dec ? 'any' : '1') : null, inputmode: c.t === 'number' ? (c.dec ? 'decimal' : 'numeric') : null,
        autocapitalize: c.up ? 'characters' : null,
      });
    }
    if (valor !== undefined && valor !== null && valor !== '') e.value = String(valor);
    entradas = [e];
    leer = () => e.value.trim();
    wrap.append(h('label', { class: 'et', for: id }, c.l, req), e, err);
  }
  return { def: c, wrap, err, entradas, leer };
}

function crearFormulario(valores = {}) {
  const campos = {};
  const cont = h('div');
  estado.esquema.secciones.forEach((s, i) => {
    const rej = h('div', { class: 'rejilla' });
    for (const c of s.campos) { campos[c.n] = crearControl(c, valores[c.n]); rej.append(campos[c.n].wrap); }
    cont.append(h('section', { class: 'seccion' }, h('h3', {}, h('span', { class: 'num' }, i + 1), s.titulo, h('small', {}, s.ayuda || '')), rej));
  });

  const visibilidad = () => {
    for (const c of todosLosCampos()) if (c.si) campos[c.n].wrap.hidden = campos[c.si.n].leer() !== c.si.v;
  };
  for (const ctl of Object.values(campos)) {
    for (const e of ctl.entradas) {
      e.addEventListener('input', () => { ctl.wrap.classList.remove('invalida'); ctl.err.textContent = ''; visibilidad(); });
      e.addEventListener('change', visibilidad);
    }
  }
  if (campos.fechaNac && campos.edad) {
    campos.fechaNac.entradas[0].addEventListener('change', () => {
      const n = new Date(campos.fechaNac.leer() + 'T00:00:00'); if (isNaN(n)) return;
      const hoy = new Date(); let a = hoy.getFullYear() - n.getFullYear();
      if (hoy.getMonth() < n.getMonth() || (hoy.getMonth() === n.getMonth() && hoy.getDate() < n.getDate())) a--;
      if (a >= 0 && a <= 120) campos.edad.entradas[0].value = a;
    });
  }
  visibilidad();

  return {
    el: cont,
    leer() {
      const d = {};
      for (const c of todosLosCampos()) {
        const ctl = campos[c.n];
        if (ctl.wrap.hidden) continue;
        const v = ctl.leer();
        if (Array.isArray(v) ? v.length : v !== '') d[c.n] = Array.isArray(v) ? v : (c.up ? v.toUpperCase() : v);
      }
      return d;
    },
    validar() {
      const errores = {};
      for (const c of todosLosCampos()) {
        const ctl = campos[c.n];
        if (ctl.wrap.hidden) continue;
        const v = ctl.leer();
        const vacio = Array.isArray(v) ? !v.length : v === '';
        if (vacio) { if (c.req) errores[c.n] = 'Obligatorio'; continue; }
        if (Array.isArray(v)) continue;
        if (c.t === 'number') {
          const n = Number(v.replace(',', '.'));
          if (!Number.isFinite(n) || n < c.min || n > c.max) errores[c.n] = `Debe estar entre ${c.min} y ${c.max}`;
          else if (!c.dec && !Number.isInteger(n)) errores[c.n] = 'Debe ser un número entero';
        }
        if (c.patron && !new RegExp(c.patron).test(c.up ? v.toUpperCase() : v)) errores[c.n] = c.err || 'Formato no válido';
      }
      return errores;
    },
    marcar(mapa) {
      let primero = null;
      for (const ctl of Object.values(campos)) { ctl.wrap.classList.remove('invalida'); ctl.err.textContent = ''; }
      for (const [n, msg] of Object.entries(mapa || {})) {
        const ctl = campos[n];
        if (!ctl) continue;
        ctl.wrap.classList.add('invalida'); ctl.err.textContent = msg;
        if (!primero) primero = ctl;
      }
      if (primero) { primero.wrap.scrollIntoView({ block: 'center', behavior: 'smooth' }); primero.entradas[0].focus({ preventScroll: true }); }
      return !!primero;
    },
    fijar(n, v) { if (campos[n]) campos[n].entradas[0].value = v; },
  };
}

/* ---------------- Estructura de la pantalla ---------------- */
function itemsMenu() {
  const r = estado.yo.usuario.rol;
  const m = [['inicio', 'Inicio']];
  if (r !== 'consulta') m.push(['nueva', 'Nueva atención']);
  m.push(['registros', r === 'operador' ? 'Mis registros' : 'Registros']);
  if (r === 'admin') m.push(['usuarios', 'Usuarios'], ['auditoria', 'Auditoría'], ['respaldos', 'Respaldos']);
  return m;
}

function cascaron(contenido, actual) {
  const u = estado.yo.usuario;
  const empresa = (estado.esquema && estado.esquema.empresa && estado.esquema.empresa.nombre) || 'IPS de ambulancias';
  const nav = h('nav', { class: 'pestanas', 'aria-label': 'Secciones' },
    itemsMenu().map(([ruta, texto]) => h('a', { href: '#/' + ruta, 'aria-current': ruta === actual ? 'page' : null }, texto)));
  raiz.replaceChildren(
    h('header', { class: 'enc' },
      h('div', { class: 'franja' }),
      h('div', { class: 'barra' },
        h('div', { class: 'marca' }, cruz(), h('div', {}, h('b', {}, 'Registro de atención y traslado'), h('small', {}, empresa))),
        h('div', { class: 'usuario' },
          h('button', { id: 'insignia', type: 'button', class: 'pastilla', onclick: () => sincronizar(true) }),
          h('div', { class: 'quien' }, u.nombre, h('small', {}, ROLES[u.rol])),
          h('a', { class: 'btn chico', href: '#/clave' }, 'Mi clave'),
          h('button', { type: 'button', class: 'btn chico', onclick: salir }, 'Salir'))),
      nav),
    h('main', { class: 'contenido' }, contenido));
  actualizarInsignia();
}

function errorVista(cont, e, reintentar) {
  cont.append(h('div', { class: 'aviso error' }, e.red ? 'No hay conexión con el servidor. Las atenciones nuevas se siguen guardando en este equipo y se envían solas al volver la señal.' : e.message,
    reintentar ? h('div', {}, h('button', { class: 'btn chico', type: 'button', onclick: reintentar }, 'Reintentar')) : null));
}

/* ---------------- Ingreso y clave ---------------- */
function vistaLogin(mensaje) {
  const usuario = h('input', { class: 'entrada', id: 'l_usuario', autocomplete: 'username', autocapitalize: 'none', spellcheck: 'false', required: true });
  const clave = h('input', { class: 'entrada', id: 'l_clave', type: 'password', autocomplete: 'current-password', required: true });
  const ver = h('button', { type: 'button', class: 'btn chico', onclick: () => { clave.type = clave.type === 'password' ? 'text' : 'password'; ver.textContent = clave.type === 'password' ? 'Ver' : 'Ocultar'; } }, 'Ver');
  const error = h('div', { class: 'aviso error', role: 'alert', hidden: !mensaje }, mensaje || '');
  const boton = h('button', { class: 'btn primario', type: 'submit' }, 'Ingresar');
  const form = h('form', { class: 'cuerpo', onsubmit: async (e) => {
    e.preventDefault();
    error.hidden = true; boton.disabled = true; boton.textContent = 'Ingresando…';
    try {
      const d = await api('POST', '/login', { usuario: usuario.value.trim(), clave: clave.value });
      estado.yo = d; estado.csrf = d.csrf; estado.yo.debeCambiar = d.debeCambiar; estado.sinRed = false;
      if (d.debeCambiar) { render(); return; }
      await cargarEsquema();
      guardarSesionLocal();
      sincronizar();
      irA('#/inicio');
    } catch (err) {
      error.textContent = err.red ? 'No hay conexión con el servidor. Revise su internet e intente de nuevo.' : err.message;
      error.hidden = false; clave.value = ''; clave.focus();
    } finally { boton.disabled = false; boton.textContent = 'Ingresar'; }
  } },
  h('h1', {}, 'Registro de atención y traslado'),
  h('p', { class: 'sub' }, 'Ingrese con su usuario y clave.'),
  error,
  h('label', { class: 'campo', for: 'l_usuario' }, h('span', { class: 'et' }, 'Usuario'), usuario),
  h('label', { class: 'campo', for: 'l_clave' }, h('span', { class: 'et' }, 'Clave'), h('div', { class: 'clave-fila' }, clave, ver)),
  boton,
  h('p', { class: 'pie-ingreso' }, 'Si olvidó su clave, pida al administrador que la reinicie. Este sistema guarda datos de salud de pacientes: no comparta su usuario.'));
  raiz.replaceChildren(h('div', { class: 'ingreso' }, h('div', { class: 'tarjeta-ingreso' }, h('div', { class: 'franja' }), form)));
  usuario.focus();
}

function vistaClave(forzada) {
  const actual = h('input', { class: 'entrada', type: 'password', autocomplete: 'current-password', required: true });
  const nueva = h('input', { class: 'entrada', type: 'password', autocomplete: 'new-password', required: true });
  const repetir = h('input', { class: 'entrada', type: 'password', autocomplete: 'new-password', required: true });
  const error = h('div', { class: 'aviso error', role: 'alert', hidden: true });
  const boton = h('button', { class: 'btn primario', type: 'submit' }, 'Guardar clave nueva');
  const form = h('form', { class: forzada ? 'cuerpo' : 'panel', onsubmit: async (e) => {
    e.preventDefault(); error.hidden = true;
    if (nueva.value !== repetir.value) { error.textContent = 'Las dos claves nuevas no coinciden'; error.hidden = false; return; }
    boton.disabled = true;
    try {
      await api('POST', '/clave', { actual: actual.value, nueva: nueva.value });
      estado.yo.debeCambiar = false;
      aviso('Clave actualizada');
      if (forzada) { await cargarEsquema(); guardarSesionLocal(); sincronizar(); irA('#/inicio'); } else render();
    } catch (err) { error.textContent = err.message; error.hidden = false; } finally { boton.disabled = false; }
  } },
  forzada ? [h('h1', {}, 'Cree su clave personal'), h('p', { class: 'sub' }, 'La clave que recibió es temporal. Elija una que solo usted conozca.')] : null,
  error,
  h('label', { class: 'campo' }, h('span', { class: 'et' }, forzada ? 'Clave temporal recibida' : 'Clave actual'), actual),
  h('label', { class: 'campo' }, h('span', { class: 'et' }, 'Clave nueva'), nueva),
  h('label', { class: 'campo' }, h('span', { class: 'et' }, 'Repita la clave nueva'), repetir),
  h('p', { class: 'pie-ingreso' }, 'Mínimo 10 caracteres, con letras y números. No use su nombre de usuario.'),
  boton,
  forzada ? h('button', { type: 'button', class: 'enlace', onclick: salir }, 'Salir') : null);
  if (forzada) { raiz.replaceChildren(h('div', { class: 'ingreso' }, h('div', { class: 'tarjeta-ingreso' }, h('div', { class: 'franja' }), form))); actual.focus(); return; }
  const cont = h('div', {}, h('div', { class: 'titulo-fila' }, h('h2', {}, 'Cambiar mi clave')), form);
  cascaron(cont, '');
}

async function salir() {
  const n = misPendientes().length;
  if (n && !confirm(`Hay ${n} atención(es) sin enviar. Se conservan en este equipo y se enviarán cuando vuelva a ingresar con conexión. ¿Salir de todos modos?`)) return;
  try { await api('POST', '/logout', {}); } catch { /* ya no hay sesión */ }
  estado.yo = null; estado.csrf = '';
  try { localStorage.removeItem('aph_sesion_v1'); } catch { /* sin almacenamiento */ }
  location.hash = '';
  vistaLogin();
}
function sesionVencida() {
  if (!estado.yo) return;
  estado.yo = null; estado.csrf = '';
  vistaLogin('Su sesión terminó. Ingrese de nuevo; lo que estaba guardando se conserva en este equipo.');
}

/* ---------------- Inicio ---------------- */
async function vistaInicio() {
  const u = estado.yo.usuario;
  const cont = h('div', {}, h('div', { class: 'titulo-fila' }, h('div', {}, h('h2', {}, 'Inicio'), h('p', { class: 'sub' }, `Hola, ${u.nombre.split(' ')[0]}.`)),
    u.rol !== 'consulta' ? h('a', { class: 'btn primario', href: '#/nueva' }, 'Nueva atención') : null));
  cascaron(cont, 'inicio');

  const pend = misPendientes();
  if (pend.length) {
    const lista = pend.map((i) => h('li', {}, `${i.datos.nombres || ''} ${i.datos.apellidos || ''} · ${fmtFecha(i.datos.fecha)} ${i.datos.hLlamada || ''}`,
      i.rechazada ? h('span', {}, ` · No se pudo enviar: ${i.rechazada} `) : ' · en espera ',
      i.rechazada ? h('button', { class: 'enlace', type: 'button', onclick: () => { if (confirm('¿Descartar este registro? No se podrá recuperar.')) { guardarCola(leerCola().filter((x) => x.uuid !== i.uuid)); render(); } } }, 'Descartar') : null));
    cont.append(h('div', { class: 'aviso warn' }, h('b', {}, `${pend.length} atención(es) guardada(s) en este equipo sin enviar`),
      h('ul', {}, lista), h('button', { class: 'btn chico', type: 'button', onclick: () => sincronizar(true) }, 'Enviar ahora')));
  }
  if (estado.instalar) {
    cont.append(h('div', { class: 'aviso ok' }, 'Puede instalar esta aplicación en este equipo para abrirla como cualquier otra app.',
      h('div', {}, h('button', { class: 'btn chico teal', type: 'button', onclick: async () => { estado.instalar.prompt(); await estado.instalar.userChoice; estado.instalar = null; render(); } }, 'Instalar aplicación'))));
  } else if (/iphone|ipad/i.test(navigator.userAgent) && !navigator.standalone) {
    cont.append(h('div', { class: 'aviso ok' }, 'Para instalarla en iPhone o iPad: toque el botón Compartir de Safari y elija "Agregar a inicio".'));
  }

  try {
    const r = await api('GET', '/resumen');
    const mayor = Math.max(1, ...r.porEvento.map((x) => x.n));
    cont.append(
      h('div', { class: 'cifras' },
        h('div', { class: 'cifra' }, h('b', {}, r.hoy), h('span', {}, 'Atenciones hoy')),
        h('div', { class: 'cifra' }, h('b', {}, r.mes), h('span', {}, 'Este mes')),
        h('div', { class: 'cifra' }, h('b', {}, r.total), h('span', {}, u.rol === 'operador' ? 'Total mías' : 'Total registradas'))),
      h('div', { class: 'panel' }, h('h3', {}, 'Este mes por tipo de evento'),
        r.porEvento.length ? h('div', { class: 'barras' }, r.porEvento.map((x) => h('div', { class: 'barra-fila' + (x.evento === 'Accidente de tránsito' ? ' tran' : '') },
          h('span', {}, x.evento), h('div', { class: 'pista' }, h('div', { class: 'relleno', style: null })), h('b', {}, x.n))))
          : h('p', { class: 'vacio' }, 'Todavía no hay atenciones este mes.')));
    cont.querySelectorAll('.barra-fila .relleno').forEach((el, i) => { el.style.width = `${Math.round((r.porEvento[i].n / mayor) * 100)}%`; });
  } catch (e) { errorVista(cont, e, () => render()); }
}

/* ---------------- Nueva atención ---------------- */
function vistaNueva(guardada) {
  if (estado.yo.usuario.rol === 'consulta') { location.hash = '#/inicio'; return; }
  const formulario = crearFormulario({ fecha: hoyLocal(), hLlamada: horaLocal() });
  const firmaTrip = crearFirma('Firma del tripulante responsable', 'Firme con el dedo o el mouse', true);
  const firmaPac = crearFirma('Firma del paciente o acompañante', 'Si no puede firmar, explique el motivo en Tripulación', false);
  const uuidRegistro = uuid();
  const boton = h('button', { class: 'btn primario', type: 'submit' }, 'Guardar atención');

  const banner = guardada ? h('div', { class: 'aviso ok' }, `Atención ${guardada.consecutivo} guardada. `,
    guardada.id ? h('button', { class: 'enlace', type: 'button', onclick: () => descargar(`/atenciones/${guardada.id}/pdf`) }, 'Descargar soporte en PDF') : 'Se enviará al servidor cuando haya conexión.') : null;

  const form = h('form', { novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    const errores = formulario.validar();
    const hayCampos = formulario.marcar(errores);
    if (firmaTrip.vacia()) { firmaTrip.error('La firma del tripulante es obligatoria'); if (!hayCampos) firmaTrip.el.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
    if (hayCampos || firmaTrip.vacia()) { aviso('Faltan datos obligatorios, están marcados en rojo'); return; }
    const carga = { uuid: uuidRegistro, datos: formulario.leer(), firmaTrip: firmaTrip.dato(), firmaPac: firmaPac.dato() || null };
    const uid = estado.yo.usuario.id;
    boton.disabled = true; boton.textContent = 'Guardando…';
    try {
      const r = await api('POST', '/atenciones', carga);
      vistaNueva({ id: r.id, consecutivo: r.consecutivo });
      window.scrollTo(0, 0);
    } catch (err) {
      if (err.status === 400 && err.campos) {
        const { firmaTrip: ft, firmaPac: fp, ...resto } = err.campos;
        formulario.marcar(resto); if (ft) firmaTrip.error(ft); if (fp) firmaPac.error(fp);
        aviso(err.message);
      } else if (err.red || err.status === 401 || err.status >= 500) {
        if (encolar(carga, uid)) { aviso('Sin conexión: la atención quedó guardada en este equipo y se enviará sola'); vistaNueva({ consecutivo: 'pendiente de envío' }); window.scrollTo(0, 0); }
        else aviso('No hay espacio para guardar en este equipo. Conéctese para enviar.');
      } else aviso(err.message);
    } finally { boton.disabled = false; boton.textContent = 'Guardar atención'; }
  } },
  formulario.el,
  h('section', { class: 'seccion' }, h('h3', {}, h('span', { class: 'num' }, estado.esquema.secciones.length + 1), 'Firmas', h('small', {}, 'Soporte de que el servicio se prestó')),
    h('div', { class: 'rejilla' }, h('div', { class: 'w2' }, firmaTrip.el), h('div', { class: 'w2' }, firmaPac.el))),
  h('div', { class: 'acciones' },
    h('button', { class: 'btn', type: 'button', onclick: () => { if (confirm('¿Borrar todo lo escrito en este formulario?')) vistaNueva(); } }, 'Limpiar'),
    boton));

  const cont = h('div', {}, h('div', { class: 'titulo-fila' }, h('h2', {}, 'Nueva atención')), banner, form);
  cascaron(cont, 'nueva');
}

/* ---------------- Registros ---------------- */
function etiquetaEvento(t) { return h('span', { class: 'etiqueta' + (t === 'Accidente de tránsito' ? ' transito' : '') }, t); }

async function vistaRegistros() {
  const f = estado.filtros;
  const rol = estado.yo.usuario.rol;
  const cuerpo = h('tbody');
  const pie = h('div', { class: 'paginacion' });
  const avisos = h('div');
  let espera;
  const query = (conPagina) => {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries(f)) if (v && (k !== 'pagina' || conPagina)) p.set(k, v);
    return p.toString();
  };
  async function cargar() {
    avisos.replaceChildren();
    try {
      const r = await api('GET', '/atenciones?' + query(true));
      cuerpo.replaceChildren(...r.items.map((a) => {
        const abrir = () => { location.hash = `#/registro/${a.id}`; };
        return h('tr', { class: 'clic' + (a.estado === 'anulado' ? ' anulada' : ''), tabindex: '0', onclick: abrir, onkeydown: (e) => { if (e.key === 'Enter') abrir(); } },
          h('td', {}, h('b', {}, a.consecutivo), a.estado === 'anulado' ? h('div', {}, h('span', { class: 'etiqueta gris' }, 'Anulada')) : null),
          h('td', {}, fmtFecha(a.fecha)), h('td', {}, a.paciente), h('td', {}, a.num_doc), h('td', {}, etiquetaEvento(a.tipo_evento)),
          h('td', {}, a.placa || ''), h('td', {}, a.ips_receptora || ''), rol === 'operador' ? null : h('td', {}, a.creado_por_nombre));
      }));
      if (!r.items.length) avisos.append(h('p', { class: 'vacio' }, r.total ? '' : 'No hay atenciones que coincidan con la búsqueda.'));
      pie.replaceChildren(h('span', {}, `${r.total} ${r.total === 1 ? 'atención' : 'atenciones'} · página ${r.pagina} de ${r.paginas}`),
        h('div', { class: 'acciones-fila' },
          h('button', { class: 'btn chico', type: 'button', disabled: r.pagina <= 1, onclick: () => { f.pagina = r.pagina - 1; cargar(); } }, 'Anterior'),
          h('button', { class: 'btn chico', type: 'button', disabled: r.pagina >= r.paginas, onclick: () => { f.pagina = r.pagina + 1; cargar(); } }, 'Siguiente')));
    } catch (e) { cuerpo.replaceChildren(); pie.replaceChildren(); errorVista(avisos, e, cargar); }
  }
  const lanzar = () => { clearTimeout(espera); espera = setTimeout(() => { f.pagina = 1; cargar(); }, 300); };
  const campoFiltro = (etq, el, clase) => h('label', { class: 'campo ' + (clase || '') }, h('span', { class: 'et' }, etq), el);
  const q = h('input', { class: 'entrada', type: 'search', value: f.q, placeholder: 'Documento, nombre, consecutivo o placa', oninput: (e) => { f.q = e.target.value; lanzar(); } });
  const desde = h('input', { class: 'entrada', type: 'date', value: f.desde, onchange: (e) => { f.desde = e.target.value; lanzar(); } });
  const hasta = h('input', { class: 'entrada', type: 'date', value: f.hasta, onchange: (e) => { f.hasta = e.target.value; lanzar(); } });
  const evento = h('select', { class: 'entrada', onchange: (e) => { f.evento = e.target.value; lanzar(); } }, h('option', { value: '' }, 'Todos'), estado.esquema.eventos.map((x) => h('option', { value: x, selected: x === f.evento }, x)));
  const estadoSel = h('select', { class: 'entrada', onchange: (e) => { f.estado = e.target.value; lanzar(); } },
    [['', 'Todos'], ['activo', 'Activas'], ['anulado', 'Anuladas']].map(([v, t]) => h('option', { value: v, selected: v === f.estado }, t)));

  const exportar = rol === 'operador' ? null : h('div', { class: 'acciones-fila' },
    ['xlsx', 'pdf', 'docx'].map((fmt) => h('button', { class: 'btn teal chico', type: 'button', onclick: () => descargar(`/reportes/atenciones.${fmt}?${query(false)}`) }, { xlsx: 'Excel', pdf: 'PDF', docx: 'Word' }[fmt])));

  const cont = h('div', {},
    h('div', { class: 'titulo-fila' }, h('h2', {}, rol === 'operador' ? 'Mis registros' : 'Registros de atención'),
      exportar ? h('div', {}, h('span', { class: 'sub' }, 'Descargar con los filtros actuales: '), exportar) : null),
    h('div', { class: 'filtros' }, campoFiltro('Buscar', q, 'amplio'), campoFiltro('Desde', desde), campoFiltro('Hasta', hasta), campoFiltro('Evento', evento), campoFiltro('Estado', estadoSel)),
    h('div', { class: 'tabla-caja' }, h('table', {},
      h('thead', {}, h('tr', {}, ['Consecutivo', 'Fecha', 'Paciente', 'Documento', 'Evento', 'Placa', 'Institución que recibe', rol === 'operador' ? null : 'Registró'].map((t) => (t ? h('th', {}, t) : null)))), cuerpo)),
    avisos, pie);
  cascaron(cont, 'registros');
  cargar();
}

/* ---------------- Detalle de una atención ---------------- */
function pedirMotivo(destino, titulo, textoBoton, accion) {
  const caja = h('textarea', { class: 'entrada', rows: 2, maxlength: 300, placeholder: 'Motivo (mínimo 5 caracteres)' });
  const err = h('div', { class: 'aviso error', hidden: true });
  const panel = h('div', { class: 'panel' }, h('h3', {}, titulo), err, caja,
    h('div', { class: 'acciones-fila' },
      h('button', { class: 'btn primario chico', type: 'button', onclick: async () => {
        try { await accion(caja.value.trim()); panel.remove(); } catch (e) { err.textContent = e.message; err.hidden = false; }
      } }, textoBoton),
      h('button', { class: 'btn chico', type: 'button', onclick: () => panel.remove() }, 'Cancelar')));
  destino.prepend(panel); caja.focus();
}

function hojaDeAtencion(a) {
  const dato = (c, v) => h('div', { class: 'dato' + (c.t === 'textarea' || c.t === 'multi' || c.w === 'full' ? ' ancho' : '') }, h('dt', {}, c.l), h('dd', {}, c.t === 'date' ? fmtFecha(v) : (Array.isArray(v) ? v.join(', ') : v)));
  const secciones = estado.esquema.secciones.map((s) => {
    const items = s.campos.filter((c) => (!c.si || a.datos[c.si.n] === c.si.v) && a.datos[c.n] !== undefined && a.datos[c.n] !== '' && !(Array.isArray(a.datos[c.n]) && !a.datos[c.n].length));
    return items.length ? h('div', { class: 'hoja-sec' }, h('h3', {}, s.titulo), h('dl', { class: 'datos' }, items.map((c) => dato(c, a.datos[c.n])))) : null;
  });
  const firma = (src, rotulo, nombre) => h('div', {}, src ? h('img', { src, alt: `Firma: ${rotulo}` }) : h('div', { class: 'nada' }), h('p', {}, h('b', {}, rotulo)), h('p', { class: 'sub' }, nombre || ''));
  return h('div', { class: 'hoja' },
    h('div', { class: 'hoja-cab' },
      h('div', {}, h('div', { class: 'consec' }, a.consecutivo),
        h('div', { class: 'sub' }, `Registrado ${fmtFechaHora(a.creado_en)} por ${a.creado_por_nombre}`),
        a.version > 1 ? h('div', { class: 'sub' }, `Versión ${a.version}, editada por ${a.actualizado_por_nombre || 'el administrador'} el ${fmtFechaHora(a.actualizado_en)}`) : null),
      h('div', {}, a.estado === 'anulado' ? h('span', { class: 'etiqueta transito' }, 'ANULADA') : h('span', { class: 'etiqueta' }, 'Activa'), etiquetaEvento(a.datos.tipoEvento))),
    a.estado === 'anulado' ? h('div', { class: 'hoja-sec' }, h('div', { class: 'aviso error' }, `Anulada: ${a.motivo_anulacion || 'sin motivo'}`)) : null,
    secciones,
    h('div', { class: 'hoja-sec' }, h('h3', {}, 'Firmas'), h('div', { class: 'firmas-vista' },
      firma(a.firma_trip, 'Tripulante responsable', a.datos.tripulante),
      firma(a.firma_pac, 'Paciente o acompañante', a.datos.acompNombre || `${a.datos.nombres} ${a.datos.apellidos}`))));
}

async function vistaDetalle(id) {
  const rol = estado.yo.usuario.rol;
  const cont = h('div');
  cascaron(cont, 'registros');
  let a;
  try { a = await api('GET', `/atenciones/${encodeURIComponent(id)}`); } catch (e) { errorVista(cont, e, () => render()); cont.prepend(h('a', { class: 'btn', href: '#/registros' }, 'Volver')); return; }

  const zona = h('div');
  const barra = h('div', { class: 'acciones-fila' },
    h('a', { class: 'btn', href: '#/registros' }, 'Volver'),
    h('button', { class: 'btn teal', type: 'button', onclick: () => descargar(`/atenciones/${a.id}/pdf`) }, 'Soporte PDF'),
    h('button', { class: 'btn teal', type: 'button', onclick: () => descargar(`/atenciones/${a.id}/docx`) }, 'Soporte Word'));
  if (rol === 'admin') {
    barra.append(
      h('button', { class: 'btn', type: 'button', onclick: () => editar() }, 'Editar'),
      h('button', { class: 'btn', type: 'button', onclick: () => historial() }, 'Historial de cambios'),
      a.estado === 'anulado'
        ? h('button', { class: 'btn', type: 'button', onclick: async () => { if (confirm('¿Reactivar esta atención?')) { await api('POST', `/atenciones/${a.id}/reactivar`, {}); render(); } } }, 'Reactivar')
        : h('button', { class: 'btn peligro', type: 'button', onclick: () => pedirMotivo(zona, 'Anular esta atención', 'Anular', async (m) => { await api('POST', `/atenciones/${a.id}/anular`, { motivo: m }); aviso('Atención anulada'); render(); }) }, 'Anular'));
  }
  cont.append(h('div', { class: 'titulo-fila' }, h('h2', {}, 'Detalle de la atención'), barra), zona, hojaDeAtencion(a));

  async function historial() {
    try {
      const filas = await api('GET', `/atenciones/${a.id}/historial`);
      zona.replaceChildren(h('div', { class: 'panel' }, h('h3', {}, 'Historial de cambios'),
        filas.length ? h('div', { class: 'historial' }, filas.map((x) => h('div', { class: 'item' },
          h('b', {}, `Versión ${x.version} reemplazada el ${fmtFechaHora(x.editado_en)} por ${x.editado_por}`), h('div', {}, `Motivo: ${x.motivo}`),
          Object.entries(x.cambios).map(([campo, [antes, despues]]) => h('div', {}, `${campo}: `, h('span', { class: 'antes' }, antes || '(vacío)'), ` → ${despues || '(vacío)'}`)))))
          : h('p', { class: 'vacio' }, 'Esta atención no ha sido modificada.')));
    } catch (e) { aviso(e.message); }
  }

  function editar() {
    const formulario = crearFormulario(a.datos);
    const motivo = h('textarea', { class: 'entrada', rows: 2, maxlength: 300, placeholder: 'Explique por qué se hace el cambio (queda en el historial)' });
    const err = h('div', { class: 'aviso error', hidden: true });
    const enviar = h('button', { class: 'btn primario', type: 'submit' }, 'Guardar cambios');
    const form = h('form', { novalidate: true, onsubmit: async (e) => {
      e.preventDefault(); err.hidden = true;
      const hay = formulario.marcar(formulario.validar());
      if (hay) { aviso('Revise los campos marcados en rojo'); return; }
      enviar.disabled = true;
      try { await api('PUT', `/atenciones/${a.id}`, { datos: formulario.leer(), motivo: motivo.value.trim() }); aviso('Cambios guardados'); render(); }
      catch (er) { if (er.campos) formulario.marcar(er.campos); err.textContent = er.message; err.hidden = false; } finally { enviar.disabled = false; }
    } },
    h('div', { class: 'aviso warn' }, 'Está editando un registro clínico. Las firmas no se pueden cambiar. Cada modificación conserva la versión anterior, quién la hizo y el motivo.'),
    formulario.el,
    h('div', { class: 'panel' }, h('h3', {}, 'Motivo del cambio'), err, motivo),
    h('div', { class: 'acciones' }, h('button', { class: 'btn', type: 'button', onclick: () => render() }, 'Cancelar'), enviar));
    cont.replaceChildren(h('div', { class: 'titulo-fila' }, h('h2', {}, `Editar ${a.consecutivo}`)), form);
    window.scrollTo(0, 0);
  }
}

/* ---------------- Usuarios (administrador) ---------------- */
async function vistaUsuarios() {
  const zona = h('div');
  const cuerpo = h('tbody');
  const cont = h('div');
  cascaron(cont, 'usuarios');

  function mostrarClave(usuario, clave, motivo) {
    zona.replaceChildren(h('div', { class: 'aviso ok' },
      h('b', {}, `${motivo} ${usuario}`), h('div', {}, 'Clave temporal (entréguela en persona; no se vuelve a mostrar):'),
      h('div', { class: 'clave-temporal' }, clave), h('div', {}, 'Al ingresar, el sistema le pedirá crear su propia clave.'),
      h('button', { class: 'btn chico', type: 'button', onclick: () => zona.replaceChildren() }, 'Ya la anoté')));
    zona.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  async function cargar() {
    let lista;
    try { lista = await api('GET', '/usuarios'); } catch (e) { errorVista(zona, e, cargar); return; }
    cuerpo.replaceChildren(...lista.map((u) => {
      const yoMismo = u.id === estado.yo.usuario.id;
      const rol = h('select', { class: 'sel-chico', 'aria-label': `Rol de ${u.usuario}`, disabled: yoMismo, onchange: async (e) => {
        if (!confirm(`¿Cambiar el rol de ${u.usuario} a ${ROLES[e.target.value]}? Se cerrarán sus sesiones abiertas.`)) { e.target.value = u.rol; return; }
        try { await api('PUT', `/usuarios/${u.id}`, { rol: e.target.value }); aviso('Rol actualizado'); cargar(); } catch (er) { aviso(er.message); e.target.value = u.rol; }
      } }, Object.entries(ROLES).map(([v, t]) => h('option', { value: v, selected: v === u.rol }, t)));
      return h('tr', {},
        h('td', {}, h('b', {}, u.usuario)), h('td', {}, u.nombre), h('td', {}, rol),
        h('td', {}, u.activo ? (u.bloqueado ? h('span', { class: 'etiqueta transito' }, 'Bloqueado') : h('span', { class: 'etiqueta' }, u.debe_cambiar ? 'Activo, sin estrenar clave' : 'Activo')) : h('span', { class: 'etiqueta gris' }, 'Inactivo')),
        h('td', {}, u.ultimo_acceso ? fmtFechaHora(u.ultimo_acceso) : 'Nunca'),
        h('td', {}, h('div', { class: 'acciones-fila' },
          h('button', { class: 'btn chico', type: 'button', onclick: async () => {
            if (!confirm(`¿Reiniciar la clave de ${u.usuario}? Se cerrarán sus sesiones abiertas.`)) return;
            try { const r = await api('POST', `/usuarios/${u.id}/reiniciar-clave`, {}); mostrarClave(u.usuario, r.claveTemporal, 'Nueva clave temporal para'); cargar(); } catch (er) { aviso(er.message); }
          } }, 'Reiniciar clave'),
          u.bloqueado ? h('button', { class: 'btn chico', type: 'button', onclick: async () => { await api('PUT', `/usuarios/${u.id}`, { desbloquear: true }); cargar(); } }, 'Desbloquear') : null,
          yoMismo ? null : h('button', { class: 'btn chico ' + (u.activo ? 'peligro' : ''), type: 'button', onclick: async () => {
            if (u.activo && !confirm(`¿Desactivar a ${u.usuario}? No podrá ingresar, pero sus registros se conservan.`)) return;
            try { await api('PUT', `/usuarios/${u.id}`, { activo: !u.activo }); cargar(); } catch (er) { aviso(er.message); }
          } }, u.activo ? 'Desactivar' : 'Activar'))));
    }));
  }

  const nombreUsuario = h('input', { class: 'entrada', required: true, autocomplete: 'off', autocapitalize: 'none', placeholder: 'ej. ana.torres', maxlength: 30 });
  const nombreCompleto = h('input', { class: 'entrada', required: true, autocomplete: 'off', maxlength: 80 });
  const rolNuevo = h('select', { class: 'entrada' }, h('option', { value: 'operador' }, 'Tripulación (registra atenciones)'), h('option', { value: 'consulta' }, 'Consulta (oficina: ve registros y saca reportes)'), h('option', { value: 'admin' }, 'Administrador'));
  const errNuevo = h('div', { class: 'aviso error', hidden: true });
  const crear = h('form', { class: 'panel', onsubmit: async (e) => {
    e.preventDefault(); errNuevo.hidden = true;
    try {
      const r = await api('POST', '/usuarios', { usuario: nombreUsuario.value.trim(), nombre: nombreCompleto.value.trim(), rol: rolNuevo.value });
      mostrarClave(nombreUsuario.value.trim(), r.claveTemporal, 'Usuario creado:');
      nombreUsuario.value = ''; nombreCompleto.value = ''; cargar();
    } catch (er) { errNuevo.textContent = er.message; errNuevo.hidden = false; }
  } },
  h('h3', {}, 'Crear usuario'), errNuevo,
  h('div', { class: 'filtros' },
    h('label', { class: 'campo' }, h('span', { class: 'et' }, 'Usuario'), nombreUsuario),
    h('label', { class: 'campo amplio' }, h('span', { class: 'et' }, 'Nombre completo'), nombreCompleto),
    h('label', { class: 'campo amplio' }, h('span', { class: 'et' }, 'Rol'), rolNuevo),
    h('button', { class: 'btn primario', type: 'submit' }, 'Crear usuario')));

  cont.append(h('div', { class: 'titulo-fila' }, h('div', {}, h('h2', {}, 'Usuarios'), h('p', { class: 'sub' }, 'Cada persona debe tener su propio usuario: así queda registrado quién hizo cada cosa.'))),
    zona, crear,
    h('div', { class: 'tabla-caja' }, h('table', {}, h('thead', {}, h('tr', {}, ['Usuario', 'Nombre', 'Rol', 'Estado', 'Último ingreso', 'Acciones'].map((t) => h('th', {}, t)))), cuerpo)));
  cargar();
}

/* ---------------- Auditoría (administrador) ---------------- */
async function vistaAuditoria(pagina = 1) {
  const cont = h('div');
  cascaron(cont, 'auditoria');
  cont.append(h('div', { class: 'titulo-fila' }, h('div', {}, h('h2', {}, 'Auditoría'), h('p', { class: 'sub' }, 'Registro de quién ingresó, creó, cambió, anuló o descargó información. No se puede editar ni borrar.')),
    h('button', { class: 'btn teal', type: 'button', onclick: () => descargar('/reportes/auditoria.xlsx') }, 'Descargar en Excel')));
  try {
    const r = await api('GET', `/auditoria?pagina=${pagina}`);
    const corto = (s) => (s && s.length > 220 ? s.slice(0, 220) + '…' : (s || ''));
    cont.append(
      h('div', { class: 'tabla-caja' }, h('table', {}, h('thead', {}, h('tr', {}, ['Fecha y hora', 'Usuario', 'Acción', 'Detalle', 'IP'].map((t) => h('th', {}, t)))),
        h('tbody', {}, r.items.map((x) => h('tr', {}, h('td', {}, fmtFechaHora(x.fecha)), h('td', {}, x.usuario || ''), h('td', {}, h('span', { class: 'etiqueta' }, x.accion)), h('td', {}, corto(x.detalle)), h('td', {}, x.ip || '')))))),
      h('div', { class: 'paginacion' }, h('span', {}, `${r.total} eventos · página ${r.pagina} de ${r.paginas}`),
        h('div', { class: 'acciones-fila' },
          h('button', { class: 'btn chico', type: 'button', disabled: r.pagina <= 1, onclick: () => vistaAuditoria(r.pagina - 1) }, 'Anterior'),
          h('button', { class: 'btn chico', type: 'button', disabled: r.pagina >= r.paginas, onclick: () => vistaAuditoria(r.pagina + 1) }, 'Siguiente'))));
  } catch (e) { errorVista(cont, e, () => vistaAuditoria(pagina)); }
}

/* ---------------- Respaldos (administrador) ---------------- */
async function vistaRespaldos() {
  const lista = h('tbody');
  const cont = h('div');
  cascaron(cont, 'respaldos');
  const pintar = (filas) => lista.replaceChildren(...(filas.length ? filas.map((f) => h('tr', {}, h('td', {}, f.archivo), h('td', {}, fmtFechaHora(f.fecha)), h('td', {}, `${(f.bytes / 1024).toFixed(0)} KB`)))
    : [h('tr', {}, h('td', { colspan: 3 }, 'Todavía no hay respaldos automáticos.'))]));
  cont.append(
    h('div', { class: 'titulo-fila' }, h('div', {}, h('h2', {}, 'Respaldos de la base de datos'),
      h('p', { class: 'sub' }, 'El servidor crea una copia automática cada día y conserva las últimas 14. Además puede bajar una copia a su computador.'))),
    h('div', { class: 'panel' },
      h('div', { class: 'acciones-fila' },
        h('button', { class: 'btn teal', type: 'button', onclick: () => descargar('/respaldo/descargar') }, 'Descargar copia de la base de datos'),
        h('button', { class: 'btn', type: 'button', onclick: async () => { try { pintar(await api('POST', '/respaldos', {})); aviso('Respaldo creado'); } catch (e) { aviso(e.message); } } }, 'Crear respaldo en el servidor ahora')),
      h('p', { class: 'sub' }, 'La copia contiene datos de salud de pacientes. Guárdela en un lugar protegido y no la envíe por WhatsApp ni correo sin cifrar.')),
    h('div', { class: 'tabla-caja' }, h('table', {}, h('thead', {}, h('tr', {}, ['Archivo', 'Fecha', 'Tamaño'].map((t) => h('th', {}, t)))), lista)));
  try { pintar(await api('GET', '/respaldos')); } catch (e) { errorVista(cont, e); }
}

/* ---------------- Arranque y navegación ---------------- */
async function cargarEsquema() {
  estado.esquema = await api('GET', '/esquema');
  try { localStorage.setItem('aph_esquema_v1', JSON.stringify(estado.esquema)); } catch { /* sin almacenamiento */ }
}
function guardarSesionLocal() { try { localStorage.setItem('aph_sesion_v1', JSON.stringify(estado.yo)); } catch { /* sin almacenamiento */ } }
function irA(hash) { if (location.hash === hash) render(); else location.hash = hash; }

async function recuperar() {
  try {
    const d = await api('GET', '/yo');
    estado.yo = { usuario: d.usuario, debeCambiar: d.debeCambiar }; estado.csrf = d.csrf; estado.sinRed = false;
    if (!d.debeCambiar) { if (!estado.esquema) await cargarEsquema(); guardarSesionLocal(); }
    return true;
  } catch (e) {
    if (e.red) {
      // Sin señal: se puede seguir registrando atenciones con los datos guardados en el equipo
      try {
        const s = JSON.parse(localStorage.getItem('aph_sesion_v1') || 'null');
        const q = JSON.parse(localStorage.getItem('aph_esquema_v1') || 'null');
        if (s && q && !estado.yo) { estado.yo = s; estado.esquema = q; }
        if (estado.yo) estado.sinRed = true;
      } catch { /* sin datos locales */ }
    } else { estado.yo = null; estado.csrf = ''; }
    return false;
  }
}

async function render() {
  if (!estado.yo) { vistaLogin(); return; }
  if (estado.yo.debeCambiar) { vistaClave(true); return; }
  if (!estado.esquema) { try { await cargarEsquema(); } catch (e) { raiz.replaceChildren(h('div', { class: 'ingreso' }, h('div', { class: 'aviso error' }, e.red ? 'No hay conexión con el servidor.' : e.message, h('div', {}, h('button', { class: 'btn chico', type: 'button', onclick: render }, 'Reintentar'))))); return; } }
  const [r, arg] = (location.hash.replace(/^#\/?/, '') || 'inicio').split('/');
  if (['usuarios', 'auditoria', 'respaldos'].includes(r) && estado.yo.usuario.rol !== 'admin') { irA('#/inicio'); return; }
  window.scrollTo(0, 0);
  switch (r) {
    case 'nueva': return vistaNueva();
    case 'registros': return vistaRegistros();
    case 'registro': return vistaDetalle(arg);
    case 'usuarios': return vistaUsuarios();
    case 'auditoria': return vistaAuditoria();
    case 'respaldos': return vistaRespaldos();
    case 'clave': return vistaClave(false);
    default: return vistaInicio();
  }
}

function registrarServiceWorker() {
  if (!('serviceWorker' in navigator)) return;
  if (location.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(location.hostname)) return;
  navigator.serviceWorker.register('/sw.js').catch(() => {});
}

async function iniciar() {
  registrarServiceWorker();
  window.addEventListener('hashchange', render);
  window.addEventListener('online', async () => { actualizarInsignia(); if (estado.sinRed || !estado.csrf) await recuperar(); sincronizar(); });
  window.addEventListener('offline', actualizarInsignia);
  window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); estado.instalar = e; });
  window.addEventListener('appinstalled', () => { estado.instalar = null; });
  setInterval(async () => { if (!estado.yo) return; if (estado.sinRed) await recuperar(); sincronizar(); }, 30000);
  await recuperar();
  await render();
  sincronizar();
}
iniciar();
})();

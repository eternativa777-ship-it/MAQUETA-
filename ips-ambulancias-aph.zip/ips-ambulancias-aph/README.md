# Registro de atención y traslado (IPS de ambulancias)

Aplicación web instalable (PWA) para registrar atenciones prehospitalarias y traslados, con base de datos, usuarios con contraseña, administrador, historial de cambios y reportes en **PDF, Word y Excel**.

Funciona en computador (Windows, Mac, Linux) y en celular (Android y iPhone). Se instala desde el navegador, sin tienda de aplicaciones, y **guarda las atenciones aunque no haya señal** y las envía solas cuando vuelve la conexión.

## Qué incluye

| Función | Detalle |
|---|---|
| Registro de atención | Formulario de 7 secciones (servicio, evento, paciente, valoración, procedimientos, entrega, tripulación) con firma manuscrita del tripulante y del paciente. Si el evento es accidente de tránsito aparecen los datos del SOAT. |
| Consecutivo | Automático por año: `APH-2026-000001`. |
| Roles | **Administrador**: todo. **Tripulación**: registra y ve solo lo suyo. **Consulta** (oficina): ve todo y saca reportes, no crea ni modifica. |
| Administrador | Crea usuarios, reinicia claves, desbloquea cuentas, edita o anula atenciones (siempre con motivo), ve la auditoría y los respaldos. |
| Trazabilidad | Cada edición guarda la versión anterior, quién la hizo y por qué. Las atenciones **no se borran**, se anulan. Todo queda en el registro de auditoría. |
| Reportes | Soporte individual en PDF y Word. Listados con filtros en Excel (con hoja de resumen), PDF y Word. Auditoría en Excel. |
| Base de datos | SQLite (un solo archivo). Respaldo automático diario (últimos 14) y descarga manual desde la app. |

## 1. Probarlo en su computador

Necesita [Node.js](https://nodejs.org) 20 o superior.

```bash
npm install
npm start
```

En Windows también puede hacer doble clic en `iniciar.bat`.

Abra <http://localhost:3000>. **La primera vez** la consola muestra el usuario `admin` y una clave temporal; el sistema le pedirá cambiarla al ingresar. Anótela en ese momento, no se vuelve a mostrar.

Si olvida la clave del administrador: `node scripts/reiniciar-clave.js admin`

## 2. Instalarlo como aplicación

Requiere que el sitio se abra por **HTTPS** (en `localhost` funciona sin HTTPS; en la red local o en internet no).

- **PC (Chrome o Edge):** icono de instalar al final de la barra de direcciones, o la tarjeta "Instalar aplicación" en la pantalla de inicio.
- **Android (Chrome):** menú de tres puntos, *Instalar aplicación*.
- **iPhone/iPad (Safari):** botón Compartir, *Agregar a pantalla de inicio*.

## 3. Publicarlo en internet

**GitHub solo guarda el código; no ejecuta esta aplicación.** GitHub Pages no sirve porque el sistema necesita un servidor (base de datos y contraseñas). Suba el código a GitHub (repositorio **privado**) y despliéguelo en uno de estos lugares:

### Opción A: servidor propio (VPS) con Docker y HTTPS automático

Es la más simple para tener los datos bajo su control. Sirve cualquier VPS pequeño con Docker. Esta configuración no se probó con Docker en el entorno donde se construyó el sistema; pruébela primero con datos falsos.

1. Apunte un subdominio (por ejemplo `ambulancias.suempresa.com`) a la IP del servidor.
2. Copie el proyecto al servidor y cree un archivo `.env` junto a `docker-compose.yml`:
   ```
   DOMINIO=ambulancias.suempresa.com
   EMPRESA_NOMBRE=Nombre de su IPS
   EMPRESA_NIT=900.000.000-0
   ```
3. `docker compose up -d --build`
4. Vea la clave inicial del administrador: `docker compose logs app`

Los datos quedan en el volumen `datos` de Docker. **Haga copias de ese volumen fuera del servidor.**

### Opción B: plataformas como Railway o Render

Conecte el repositorio de GitHub y agregue las variables de entorno de la sección 5 (con `TRUST_PROXY=1`). **Es imprescindible un disco o volumen persistente montado en la carpeta de datos** (`DATA_DIR`); si el plan no lo incluye, cada reinicio borra la base de datos. Revise las condiciones del plan antes de usarlo con datos reales.

## 4. Uso diario

1. El administrador crea un usuario por cada persona (nunca compartan usuarios: la auditoría depende de eso) y entrega la clave temporal en persona.
2. La tripulación ingresa desde el celular, entra a **Nueva atención**, llena, firma y guarda.
3. Sin señal, la atención queda en el celular ("1 sin enviar") y se envía sola. No se pierde si cierra la app, pero **no cierre sesión ni borre los datos del navegador** con atenciones pendientes.
4. La oficina (rol Consulta) entra a **Registros**, filtra por fechas o evento y descarga Excel, PDF o Word.
5. Si hay un error en un registro, solo el administrador puede corregirlo, indicando el motivo.

## 5. Variables de entorno

Copie `.env.example` como `.env` o defínalas en el servidor.

| Variable | Para qué sirve | Por defecto |
|---|---|---|
| `PORT` | Puerto del servidor | `3000` |
| `DATA_DIR` | Carpeta de la base de datos y los respaldos | `./data` |
| `EMPRESA_NOMBRE`, `EMPRESA_NIT` | Encabezado de los reportes | vacío |
| `TRUST_PROXY` | `1` si está detrás de un proxy con HTTPS (Docker con Caddy, Railway, Render) | `0` |
| `SESION_HORAS` | Duración de una sesión (1 a 72) | `12` |
| `ADMIN_CLAVE_INICIAL` | Clave inicial del admin (si no se define, se genera al azar) | aleatoria |

## 6. Seguridad

**Lo que ya hace el sistema**

- Claves guardadas con `scrypt` (nunca en texto plano); mínimo 10 caracteres con letras y números.
- Cuenta bloqueada 15 minutos tras 5 intentos fallidos; límite de intentos por dirección de red.
- Cookie de sesión `HttpOnly` y `SameSite=Strict` (y `Secure` bajo HTTPS); protección contra CSRF con token; se rechazan peticiones que vienen de otros sitios.
- La clave temporal obliga a crear una propia antes de usar el sistema.
- Roles verificados en el servidor (no solo en pantalla). Un usuario de tripulación no puede ver lo de otro.
- Consultas SQL parametrizadas, validación de cada campo en el servidor, y la pantalla arma todo con `textContent` (no ejecuta HTML ni scripts que vengan en los datos).
- Política de contenido (CSP) estricta y cabeceras de seguridad.
- Auditoría de ingresos, fallos, creaciones, ediciones, anulaciones, descargas y cambios de usuarios.
- El administrador no puede quitarse su propio rol ni dejar el sistema sin administradores.

**Lo que usted debe garantizar**

- **Use siempre HTTPS** fuera de su computador.
- La base de datos **no está cifrada en el disco**: use un servidor con disco cifrado y acceso restringido.
- Los respaldos contienen datos de salud: guárdelos protegidos y no los envíe por chat o correo sin cifrar.
- Los datos de salud son información sensible: revise con su área jurídica y de calidad el cumplimiento de la Ley 1581 de 2012 (protección de datos), las normas de historia clínica y los tiempos de conservación que apliquen a su IPS.
- **Nunca suba a GitHub** las carpetas `data/` ni el archivo `.env` (ya están en `.gitignore`).
- Este sistema no incluye doble factor de autenticación. Antes de usarlo con datos reales de pacientes conviene una revisión de seguridad independiente.

## 7. Cambiar o agregar campos del formulario

Todo el formulario, la validación y las columnas de los reportes salen de un solo archivo: `src/esquema.js`. Para ajustar el formato a los documentos oficiales de su IPS, edite ese archivo y reinicie el servidor. Los registros ya guardados se conservan.

## 8. Limitaciones conocidas

- No genera todavía el **FURIPS** ni los **RIPS** oficiales; el Excel exportado trae los datos necesarios para prepararlos.
- Sin señal solo se pueden **registrar** atenciones; consultar registros o reportes requiere conexión.
- Una persona cuya sesión venció mientras no había señal no puede volver a ingresar hasta que haya conexión.
- Es una aplicación web instalable; no es una aplicación de tienda (Play Store o App Store).

## 9. Pruebas

```bash
npm test
```

Levanta el sistema con una base de datos temporal y verifica ingreso, roles, bloqueo de cuenta, validaciones, intentos de inyección, reportes en los tres formatos, respaldos y auditoría.

'use strict';
/* Reinicia la clave de un usuario desde la consola del servidor (por ejemplo si el administrador olvidó la suya).
 * Uso:  node scripts/reiniciar-clave.js admin
 * Genera una clave temporal, desbloquea la cuenta, cierra sus sesiones y exige cambiarla al ingresar.
 * Solo puede ejecutarlo quien tiene acceso al servidor.                                                       */
const path = require('path');
const { abrir, auditar } = require('../src/db');
const seg = require('../src/seguridad');

(async () => {
  const usuario = process.argv[2];
  if (!usuario) { console.error('Uso: node scripts/reiniciar-clave.js <usuario>'); process.exit(1); }
  const dir = path.resolve(process.env.DATA_DIR || path.join(__dirname, '..', 'data'));
  const db = abrir(dir);
  const u = db.prepare('SELECT * FROM usuarios WHERE usuario = ?').get(usuario);
  if (!u) { console.error(`No existe el usuario "${usuario}".`); process.exit(1); }
  const temporal = seg.claveTemporal();
  db.prepare('UPDATE usuarios SET clave_hash=?, debe_cambiar=1, activo=1, intentos=0, bloqueado_hasta=0 WHERE id=?').run(await seg.hashClave(temporal), u.id);
  db.prepare('DELETE FROM sesiones WHERE usuario_id = ?').run(u.id);
  auditar(db, null, 'CLAVE_REINICIADA_CONSOLA', 'usuario', u.id, { usuario }, { id: null, usuario: 'consola del servidor' });
  console.log(`\nClave temporal para "${usuario}": ${temporal}\nEl sistema le pedirá cambiarla al ingresar.\n`);
  db.close();
})();
